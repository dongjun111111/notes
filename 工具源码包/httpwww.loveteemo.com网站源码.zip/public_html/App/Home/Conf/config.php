<?php
//定义回调URL通用的URL
return array(
    //腾讯QQ登录配置
    'THINK_SDK_QQ' => array(
        'APP_KEY' => '101232670', //应用注册成功后分配的 APP ID
        'APP_SECRET' => '47d496c5cab11fad38b140e19084977f', //应用注册成功后分配的KEY
        //'CALLBACK' => URL_CALLBACK . 'qq',
        'CALLBACK' => 'http://loveteemo.com',
    ),
        //'配置项'=>'配置值'
        'URL_MODEL' =>2,    //开启路由
        'URL_ROUTER_ON' => true,    //路由规则
        'URL_ROUTE_RULES' => array(
        '/^index$/'           =>    'Index/index',
        '/^about$/'           =>    'About/index', 
        // feel 对应列表页
        // feel/page/2 对应分页
        // feel-2 对应详情
        '/^feel$/'              =>  'Feel/index',
        '/^feel\/page\/(\d{1,})$/'  =>  'Feel/index?page=:1',
        '/^feel-(\d{1,})$/'     =>  'Feel/index?id=:1',
        '/^gustbook$/'          =>  'Gustbook/index',
        '/^gustbook\/(\d{1,})$/'	=>	'Gustbook/index?page=:1',
        '/^album-(\d{1,5})$/'   =>  'Album/look?id=:1',
        '/^album$/'             =>  'Album/index',
        '/^class-(\d{1,})\/page\/(\d{1,})$/'        =>  'Class/index?id=:1&page=:2',
        '/^class-(\d)$/'        =>  'Class/index?id=:1',
        '/^article-(\d{1,5})$/' =>  'Article/index?id=:1',
    ),
);