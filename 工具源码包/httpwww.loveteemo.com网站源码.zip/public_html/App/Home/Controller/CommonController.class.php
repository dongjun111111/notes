<?php
/**
 * 系统自动加载类
 * author long
 * time 2015/7/12 
 */
namespace Home\Controller;
use Think\Controller;
use Org\ThinkSDK\ThinkOauth;
class CommonController extends Controller{
        public function _initialize(){
            // 判断是否QQ登陆
            if(!session('qqname')){            
                if($_GET['code']){
                    $code = I('get.code');
                    $sns = ThinkOauth::getInstance('QQ');
                    $extend = null;
                    $token = $sns->getAccessToken($code, $extend);
                    $openid = $token['openid'];
                    if (is_array($token)) {
                    $data = $sns->call('user/get_user_info');
                        if ($data['ret'] == 0) {
                            $userInfo['type'] = 'QQ';
                            $userInfo['name'] = $data['nickname'];
                            $userInfo['nick'] = $data['nickname'];
                            $userInfo['head'] = $data['figureurl_1'];
                            SESSION('qqname',$userInfo['name']);
            		        SESSION('head',$userInfo['head']);
                        }
                    } 
                }
            }
            // 导航
            $this->pid = D('User/Article')->pid();    
            // top 
            $this->ip = get_client_ip();
            $this->Os = getOS();
            // 基本参数
            $system = M('system')->where('1')->find();
            $this->title_2 = $system['title_2'];
            $this->keyword = $system['keyword'];
            $this->description = $system['remark'];
            $this->site = C('SITE');
            // 网站底部参数
            $foot = array(
                'name' => C('NAME'),
                'lang' => C('LANG'),
                'frame'=>C('FRAME'),
                'charset' => C('CHARSET'),
                'author'=>C('AUTHOR'),
                'version' => M('version')->limit(1,1)->order('time desc')->getField('version')
            );
            $this->assign('foot',$foot);
            // 底部随机推荐5篇文章 待优化级别 3
            $fa = M('article')->where(array('a_view'=>2))->getField('a_id',true);
            $rt = array_rand($fa,5);
            $f1 = $fa[$rt[0]];
            $f2 = $fa[$rt[1]];
            $f3 = $fa[$rt[2]];
            $f4 = $fa[$rt[3]];
            $f5 = $fa[$rt[4]];
            $f_article[0] = M('article')->where(array('a_id'=>$f1))->find();
            $f_article[1] = M('article')->where(array('a_id'=>$f2))->find();
            $f_article[2] = M('article')->where(array('a_id'=>$f3))->find();
            $f_article[3] = M('article')->where(array('a_id'=>$f4))->find();
            $f_article[4] = M('article')->where(array('a_id'=>$f5))->find();
            $this->assign('f_article',$f_article);
            // 网站站点相关 2015-7-12 优化查询
            $time1 = strtotime(date("Y-m-d"));
            $row = $system['time'];
            $time2 = strtotime("$row");
            $num1   = M('article_content')->count();
            $num2   = M('said_content')->count();
            $num3   = M('album_content')->count();
            $num4   = M('gustbook')->count();
            $box1 = array(
                'saids'     => M('said')->where(array('s_view'=>1))->count(),
                'articles'  => M('article')->where(array('a_view >'=>1))->count(),
                'time'      => round(($time1-$time2)/3600/24),
                'num'       => $num1 + $num2 + $num3,
                'content'   => $num4,
                'albums'    => M('album')->count(),
                'picture'   => M('picture')->count(),
                'link'      => M('link')->count(),
                'pay'       => $system['pay'],
                'hit'       => $system['hit']+1
            );
            // 每访问一次 记录数加1 2015-7-12更新
            M('System')->where(array('id'=>1))->save(array('hit'=>$system['hit']+1));
            $this->copy_l = $system['copy'];
            $this->copy_r = $system['icp'].'&nbsp;&nbsp;'.$system['footer'];
            $this->assign('box1',$box1);
            $this->album = M('album')->where(array('al_view'=>1))->field(true)->select();
            // 随机文章3篇
            $arr = M('article')->getField('a_id',true);
            $rt = array_rand($arr,3);
            // 随机文章
            $a_id1 = $arr[$rt[0]];
            $a_id2 = $arr[$rt[1]];
            $a_id3 = $arr[$rt[2]];
            $s_article[0] = M('article')->where(array('a_id'=>$a_id1))->find();
            $s_article[1] = M('article')->where(array('a_id'=>$a_id2))->find();
            $s_article[2] = M('article')->where(array('a_id'=>$a_id3))->find();
            $this->assign('s_article',$s_article);
            $this->links = M('link')->where(array('l_view'=>1))->order('l_sort')->field(true)->select();
            // 最新评论
            $time = M('article_content')->field('a_c_time')->table('web_article_content')
            ->union(array('SELECT s_c_time FROM web_said_content',
                          'SELECT al_c_time FROM web_album_content order by a_c_time desc limit 0,5'
                ),ture)->SELECT();
            for($i=0;$i<5;$i++){
                $a  = M('article_content')->where(array('a_c_time'=>$time[$i]['a_c_time']))->find();
                $al = M('album_content')->where(array('al_c_time'=>$time[$i]['a_c_time']))->find();
                $s  = M('said_content')->where(array('s_c_time'=>$time[$i]['a_c_time']))->find();
                if($a!=''){
                        $s_content[] = $a;
                }elseif($al!=''){
                        $s_content[] = $al;
                }elseif($s!=''){
                        $s_content[] = $s;
                }                   
            }
            $this->assign('s_content',$s_content);
            $this->contents = M('gustbook')->order('c_time desc')->limit(5)->field(true)->select();
            // 点击排行
            $this->hits = M('article')->order('a_hit desc')->where('a_view > 0')->limit(7)->field(true)->select();
            // QQ用户名
			$this->qqname = session('qqname');   
        }
     }   
?> 