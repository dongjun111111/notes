<?php
/**
 * 系统前台首页类
 * author long
 * time 2015/7/12 
 */
namespace Home\Controller;
use Think\Controller;
class IndexController extends CommonController {
    public function index(){
		//首页 显示5篇文章
		$tag = M('article')->where("a_keyword != ''")->field('a_keyword,a_id,a_time')->order('a_time desc')->limit(30)->select();
		for($i=1;$i<count($tag);$i++){
			$tag[$i-1][id]=$i;
		}
		$this->assign('tag',$tag);
		$this->articles = M('article')->order('a_time desc')->join('web_tag ON web_tag.pid = web_article.pid')->limit(0,5)->select();
		$this->display();
    }
}