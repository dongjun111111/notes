<?php
namespace Home\Controller;
use Think\Controller;
class GustbookController extends CommonController {
	public function index(){	
		// 分页列表
			$count = M('gustbook')->count();
			$Page  = new \Think\PageHome($count,5);
            $Page->url = 'gustbook';
			$show  = $Page->show();
		    $content = M('gustbook')->order('c_time desc')->limit($Page->firstRow.','.$Page->listRows)->select();
			$this->assign('content',$content);
			$this->assign('page',$show);
			$this->display();
	}
			public function verify() {
				ob_clean();
				// 设置验证码字符为纯数字
				$verify = new \Think\Verify();
				// 设置验证码字符为纯数字 
				$verify->codeSet = '0123456789'; 
				$verify->fontSize = '10px';
				$verify->imageW = 70;
				$verify->imageH = 20;
				$verify->length = 4;
				$verify->useCurve = false;
				$verify->useNoise = false;
        		$verify->entry();
        	}        	
        	public function addContent(){
        		$txt_check = I('post.txt_check');
        		if(check_verify($txt_check) == false){
        			jumpError('验证码错误');
        		}
        		$c_email		=	I('post.u_mail');
        		$c_img = M('gustbook')->where(array('c_email'=>$c_email))->getField('c_img');
        		if($c_img==''){
        			$c_img = mt_rand(0,100);
        		}
        		$data = array(
        			'c_time'		=>	time(),
        			'c_ip'		=>	get_client_ip(),
        			'c_content'	=>	I('post.u_content'),
        			'c_name'		=>	I('post.u_name'),
        			'c_email'		=>	I('post.u_email'),
        			'c_url'		=>	I('post.u_url'),
        			'c_img'		=>	$c_img,
        			'c_from'		=>  getOs()
        			);
        		if(D('User/Gustbook')->addContent($data)){
        			$content = "<div id='contentDiv' onmouseover='getTop().stopPropagation(event);' onclick='getTop().preSwapLink(event, 'spam', 'ZC2914-IKsXmwzBblF9dlgNWDI9L54');' style='position:relative;font-size:14px;height:auto;padding:15px 15px 10px 15px;z-index:1;zoom:1;line-height:1.7;overflow:hidden;' class='body'>    <div class='' id='qm_con_body'><div style='' id='mailContentContainer' class='qmbox qm_con_body_content'>
									<div style='border:1px double #f60;'>
									<div style=' padding:10px 10px 5px 20px; font-size:12px'>亲爱的 管理员 ：您好!</div>
									<div style=' padding:10px 10px 10px 20px; font-size:12px'>[ ".I('post.u_name')." ] 给您在博客中留言如下：</div>
									<div style='padding:10px 10px 10px 10px; font-size:12px; background:#f2f2f2;border:1px double #ccc;margin:0px 15px 0px 15px; line-height:25px;'>".I('post.u_content')."</div>
									<div style=' padding:10px 10px 10px 20px; font-size:12px'><strong>温馨提示</strong> 本邮件由系统自动发出，请勿直接回复！</div>
									</div></div>
									<!-- -->
									<style>#mailContentContainer .txt {height:auto;}</style>  
								</div>";
			    	SendMail(C('MAIL_USERNAME'),'您的LoveTeemo博客上有了新的留言',$content);
//$url = 'article-'.$id;var_dump($url);die;
        			$this->success('发布留言完成',"/gustbook");
        		}else{
        			$this->error('评论失败!');
        		}
        	}
}
?>