<?php
namespace Home\Controller;
use Think\Controller;
class FeelController extends CommonController {
    public function index(){    
        //说说页
        
        if($_GET['id']){
            echo 'test';die;
        }else{
            $count = M('said')->count();
            $Page  = new \Think\PageHome($count,5);
            $Page->url = 'feel/page';
            $show  = $Page->show();
            $said = M('said')->order('s_time desc')->limit($Page->firstRow.','.$Page->listRows)->select();
            // for($i=1;$i<6;$i++){
            //  if($said[$i-1]!=''){
            //  $said[$i-1]['i']    = $i;}
            // }
            $this->assign('said',$said);
            $this->assign('page',$show);
                            // G('end');
                            // $this->time =  G('begin','end').'s';
            $this->display();
        }
        
    }
}
?>