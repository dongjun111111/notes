<?php
namespace Home\Controller;
	use Think\Controller;
		class TestController extends Controller {
                      public function index(){
$user_agent = $_SERVER['HTTP_USER_AGENT'];
var_dump($user_agent);
                      $this->display();
                       }
  }
?>