<?php
/**
 * 文章类
 * author long
 * time 2015/7/12 
 */
namespace Home\Controller;
use Think\Controller;
class ArticleController extends CommonController {
	public function index(){
		$a_id = I('get.id');
         if($a_id == ''){$this->error('404 not found');}
         if(!M('article')->where(array('a_id'=>$a_id))->select()){$this->error('404 not found');}     
		$this->Article = M('article')->join('web_tag ON web_tag.pid = web_article.pid')->where(array('web_article.a_id'=>$a_id))->find();
		// 获取点击数
		$hit = $this->Article['a_hit'];
			$data = array(
				'a_hit' => $hit+1
			);
		M('article')->where(array('a_id'=>$a_id))->save($data);	
		// 查询评论
		$this->Common = M('article_content')->where(array('a_id'=>$a_id))->select();
        // 上一篇 下一篇
		$this->up 	=  M('article')->where('a_id <'.$a_id)->order('a_id desc')->limit(1)->find();
		$this->down =  M('article')->where('a_id >'.$a_id)->order('a_id')->limit(1)->find();	
		$this->display();
	}


	public function verify() {
		ob_clean();
		// 设置验证码字符为纯数字
		$verify = new \Think\Verify();
		// 设置验证码字符为纯数字 
		$verify->codeSet = '0123456789'; 
		$verify->fontSize = '10px';
		$verify->imageW = 70;
		$verify->imageH = 20;
		$verify->length = 4;
		$verify->useCurve = false;
		$verify->useNoise = false;
		$verify->entry();
	}     


    public function addArticleContent(){
        $id = I('post.id');
        $txt_check = I('post.txt_check');
        if(check_verify($txt_check) == false){
        	jumpError('验证码错误');
        }
        $a_c_email	=	I('post.u_email');
        $a_c_img = M('article_content')->where(array('a_c_email'=>$a_c_email))->getField('a_c_img');
        if($a_c_img==''){
        	$a_c_img = mt_rand(1,100);
        }
        $data = array(
        	'a_id' 			=> I('post.id'),
        	'a_c_time'		=>	time(),
        	'a_c_ip'		=>	get_client_ip(),
        	'a_c_content'	=>	I('post.u_content'),
        	'a_c_name'		=>	I('post.u_name'),
        	'a_c_email'		=>	$a_c_email,
        	'a_c_url'		=>	I('post.u_url'),
        	'a_c_img'		=>	$a_c_img,
        	'a_c_from'		=>  getOs()
        );
        if(D('User/Article')->addArticleContent($data)){
        	$content = "<div id='contentDiv' onmouseover='getTop().stopPropagation(event);' onclick='getTop().preSwapLink(event, 'spam', 'ZC2914-IKsXmwzBblF9dlgNWDI9L54');' style='position:relative;font-size:14px;height:auto;padding:15px 15px 10px 15px;z-index:1;zoom:1;line-height:1.7;overflow:hidden;' class='body'>    <div class='' id='qm_con_body'><div style='' id='mailContentContainer' class='qmbox qm_con_body_content'><div style='border:1px double #f60;'>
						<div style=' padding:10px 10px 5px 20px; font-size:12px'>亲爱的 管理员 ：您好!</div>
						<div style=' padding:10px 10px 10px 20px; font-size:12px'>[ ".I('post.u_name')." ] 给您的文章 [ ". I('post.a_title')." ] 评论如下：</div>
						<div style='padding:10px 10px 10px 10px; font-size:12px; background:#f2f2f2;border:1px double #ccc;margin:0px 15px 0px 15px; line-height:25px;'>".I('post.u_content')."</div>
						<div style=' padding:10px 10px 10px 20px; font-size:12px'><strong>温馨提示</strong> 本邮件由系统自动发出，请勿直接回复！</div></div></div>
						<style>#mailContentContainer .txt {height:auto;}</style>  </div>";
			SendMail(C('MAIL_USERNAME'),'您的LoveTeemo博客上的文章有了新的评论',$content);
        	$this->success('发布留言完成',"/article-$id");
        }else{
        	$this->error('评论失败!');
        }
    }
}
?>