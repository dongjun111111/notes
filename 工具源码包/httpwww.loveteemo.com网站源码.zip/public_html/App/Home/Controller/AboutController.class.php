<?php
/**
 * 关于类
 * author long
 * time 2015/7/12 
 */
namespace Home\Controller;
use Think\Controller;
class AboutController extends CommonController {
    public function index(){    
        //关于我 请在视图页面修改
        $this->display();
    }
}
?>