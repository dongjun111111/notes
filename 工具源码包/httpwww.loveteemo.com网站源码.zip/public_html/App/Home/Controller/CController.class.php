<?php

namespace Home\Controller;

use Think\Controller;
use Org\ThinkSDK\ThinkOauth;

/**
 * 测试例程
 */
class CController extends Controller {

    // 定义公共方法，作用为访问Ta进入三方登录页面
    public function index() {
        // 获取QQ登录的接口对象
        $sdk = ThinkOauth::getInstance('qq');
        // 重写到模块三方登录的页面
        //var_dump($sdk);die;
        redirect($sdk->getRequestCodeURL());
    }

public function out(){
		    	// 退出
				// 清空SESSION
				session(null);
				// 转跳登陆页面
				 $this->redirect('Index/index');
			}

}

