<?php
/**
 * 文章分类
 * author long
 * time 2015/7/12 
 */
namespace Home\Controller;
use Think\Controller;
class ClassController extends CommonController {
	public function index(){	
		// 分页列表
			$id = I('get.id');
			$count = M('article')->where(array('pid'=>$id))->count();
			$Page  = new \Think\PageHome($count,5);
            $Page->url = 'class-'.$id.'/page';
			$show  = $Page->show();
		    $article = M('article')->order('a_time desc')->join('web_tag ON web_tag.pid = web_article.pid')->where(array('web_article.pid'=>$id))->limit($Page->firstRow.','.$Page->listRows)->select();
			$this->assign('article',$article);
			$this->assign('page',$show);
			$this->display();
	}
}
?>