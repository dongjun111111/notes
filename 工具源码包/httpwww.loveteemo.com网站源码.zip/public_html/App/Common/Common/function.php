<?php
	// 公共函数
	function getIp($iP){
            $taobaoIP = 'http://ip.taobao.com/service/getIpInfo.php?ip='.$iP;
            $IPinfo = json_decode(file_get_contents($taobaoIP));
            $province = $IPinfo->data->region;
            $city = $IPinfo->data->city;
            $data = $province.$city;
            return $data;
    }
	function jumpError($msg){
        echo '<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>'; 
		echo "<script>alert('$msg');history.go(-1);</script>";
		exit;
	}
	function check_verify($code, $id = ''){
    	$verify = new \Think\Verify();
    	return $verify->check($code, $id);
	}
    function getOS(){
		$os='';
		$Agent=$_SERVER['HTTP_USER_AGENT'];
		if (eregi('win',$Agent)&&strpos($Agent, '95')){
			$os='Win 95';
		}elseif(eregi('win 9x',$Agent)&&strpos($Agent, '4.90')){
			$os='Win ME';
		}elseif(eregi('win',$Agent)&&ereg('98',$Agent)){
			$os='Win 98';
		}elseif(eregi('win',$Agent)&&eregi('nt 5.0',$Agent)){
			$os='Win 2000';
		}elseif(eregi('win',$Agent)&&eregi('nt 6.0',$Agent)){
			$os='Win Vista';
		}elseif(eregi('win',$Agent)&&eregi('nt 6.1',$Agent)){
			$os='Win 7';
		}elseif(eregi('win',$Agent)&&eregi('nt 5.1',$Agent)){
			$os='Win XP';
		}elseif(eregi('win',$Agent)&&eregi('nt 6.2',$Agent)){
			$os='Win 8';
		}elseif(eregi('win',$Agent)&&eregi('nt 6.3',$Agent)){
			$os='Win 8.1';
		}elseif(eregi('win',$Agent)&&eregi('nt',$Agent)){
			$os='Win NT';
		}elseif(eregi('win',$Agent)&&ereg('32',$Agent)){
			$os='Win 32';
		}elseif(ereg('Mi',$Agent)){
			$os='小米';
		}elseif(eregi('Android',$Agent)&&ereg('LG',$Agent)){
			$os='LG';
		}elseif(eregi('Android',$Agent)&&ereg('M1',$Agent)){
			$os='魅族';
		}elseif(eregi('Android',$Agent)&&ereg('MX4',$Agent)){
			$os='魅族4';
		}elseif(eregi('Android',$Agent)&&ereg('M3',$Agent)){
			$os='魅族';
		}elseif(eregi('Android',$Agent)&&ereg('M4',$Agent)){
			$os='魅族';
		}elseif(eregi('Android',$Agent)&&ereg('H',$Agent)){
			$os='华为';
		}elseif(eregi('Android',$Agent)&&ereg('vivo',$Agent)){
			$os='Vivo';
		}elseif(eregi('Android',$Agent)){
			$os='Android';
		}elseif(eregi('linux',$Agent)){
			$os='Linux';
		}elseif(eregi('unix',$Agent)){
			$os='Unix';
		}elseif(eregi('iPhone',$Agent)){
			$os='iPhone';
		}else if(eregi('sun',$Agent)&&eregi('os',$Agent)){
			$os='SunOS';
		}elseif(eregi('ibm',$Agent)&&eregi('os',$Agent)){
			$os='IBM OS/2';
		}elseif(eregi('Mac',$Agent)&&eregi('PC',$Agent)){
			$os='Macintosh';
		}elseif(eregi('PowerPC',$Agent)){
			$os='PowerPC';
		}elseif(eregi('AIX',$Agent)){
			$os='AIX';
		}elseif(eregi('HPUX',$Agent)){
			$os='HPUX';
		}elseif(eregi('NetBSD',$Agent)){
			$os='NetBSD';
		}elseif(eregi('BSD',$Agent)){
			$os='BSD';
		}elseif(ereg('OSF1',$Agent)){
			$os='OSF1';
		}elseif(ereg('IRIX',$Agent)){
			$os='IRIX';
		}elseif(eregi('FreeBSD',$Agent)){
			$os='FreeBSD';
		}elseif($os==''){
			$os='Unknown';
		}
		return $os;
	}
	function sendMail($to, $subject, $content) {
	    vendor('phpmailer.class#phpmailer');
	    $mail = new phpmailer();
	    // 装配邮件服务器
	    if (C('MAIL_SMTP')) {
	        $mail->IsSMTP();
	    }
	    $mail->Host = C('MAIL_HOST');
	    $mail->SMTPAuth = C('MAIL_SMTPAUTH');
	    $mail->Username = C('MAIL_USERNAME');
	    $mail->Password = C('MAIL_PASSWORD');
	    $mail->SMTPSecure = C('MAIL_SECURE');
	    $mail->CharSet = C('MAIL_CHARSET');
	    // 装配邮件头信息
	    $mail->From = C('MAIL_USERNAME');
	    $mail->AddAddress($to);
	    $mail->FromName = 'LoveTeemo';
	    $mail->IsHTML(C('MAIL_ISHTML'));
	    // 装配邮件正文信息
	    $mail->Subject = $subject;
	    $mail->Body = $content;
	    // 发送邮件
	    if (!$mail->Send()) {
	        return FALSE;
	    } else {
	        return TRUE;
	    }
    }
	function delFace($str){
		for($i=1;$i<76;$i++){
			$str = str_replace("[em_$i]",'',$str);
		}
		return $str;
	}
	function reFace($str){
		for($i=1;$i<76;$i++){
			$str = str_replace("[em_$i]","<img src='/Public/Face/$i.gif'/>",$str);
		}
		return $str;
	}
	// 生成说说图1
	function reImg($str){
		if(preg_match_all("/(src)=([\"|']?)([^ \"'>]+\.(gif|jpg|jpeg|bmp|png))\\2/i", $str, $matches)){
			return $matches[0][0];
		}else{
			$num = rand(1,100);
			return "src='/Public/Img/SaidImg/pic_".$num.".jpg'";
		}
	}
	// 生成说说图2
	function reImg2($str){
		if(preg_match_all("/(src)=([\"|']?)([^ \"'>]+\.(gif|jpg|jpeg|bmp|png))\\2/i", $str, $matches)){
			return $matches[0][0];
		}else{
			return "";
		}
	}
?>