<?php
namespace User\Model;
	use Think\Model;
	class UserModel extends Model{
######################################用户操作数据模型######################################
		public function login($name,$password){
			// 登陆验证
			if($name == '' || $password == ''){
				return 0;
			}
			$login =  M('user')->where(array('name'=>$name))->find();
			if($login['password'] == $password){
				// 验证通过 更新登陆时候的IP和时间
				$data = array(
				'last_time' 	=>	time(),
				'ip'		=>	get_client_ip());		
				// 更新数据库文件
				M('user')->where(array('name'=>$name))->save($data);
				// 验证文件写入SESSION;
				SESSION('uid',$login['id']);
				SESSION('user',$login['user']);
				SESSION('name',$login['name']);
				SESSION('class',$login['class']);
				SESSION('last_time',date('Y-m-d H:i:s',$login['last_time']));
				SESSION('ip',$login['loginip']);
				return 1;
			}else{
				return 2;
			}
		}
		public function addUser($data){
			// 添加用户操作
			if(M('user')->add($data)){
				return 1;
			}else{
				return 0;
			}
		}
		public function editUser($id){
			// 编辑用户操作
			$editUser = M('user')->where(array('id'=>$id))->find();
			if($editUser){
				return $editUser;
			}else{
				return 0;
			}
		}
		public  function updataUser($id,$data){
			// 更新用户信息
			if (M('user')->where(array('id'=>$id))->save($data)){
				return 1;
			}else{
				return 0;
			}
		}
		public function delUser($id){
			// 删除用户
			if(M('user')->where(array('id'=>$id))->delete()){
				return 1;
			}else{
				return 0;
			}
		}


######################################前台数据操作模型######################################
		public function setting(){
			// 网站通用模型
			$web_setting = M('setting')->where(1)->find();
			return $web_setting;
			}
		public function articlePid($pid){
			$tag = M('tag')->where(array('pid'=>$pid))->find();
			return $tag['t_name'];
		}
	}
?>