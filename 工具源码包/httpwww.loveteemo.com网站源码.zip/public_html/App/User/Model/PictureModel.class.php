<?php
namespace User\Model;
	use Think\Model;
	class PictureModel extends Model{
######################################图片操作数据模型######################################
		public function aid(){
			// 查询栏目
			$aid = M('album')->where(array('al_view'=>1))->select();
			return $aid;
		}
		public function addPicture($data){
			// 添加栏目操作
			if(M('picture')->add($data)){
				return 1;
			}else{
				return 0;
			}
		}
		public function pictureList(){
			$pictureList = M('picture')->select();
			return $pictureList;
		}
		public function editPicture($id){
			$editPicture = M('picture')->where(array('p_id'=>$id))->find();
			if($editPicture){
				return $editPicture;
			}else{
				return 0;
			}
		}
		public function updataPicture($id,$data){
			if(M('picture')->where(array('p_id'=>$id))->save($data)){
				return 1;
			}else{
				return 0;
			}
		}
		public function delPicture($id){
			// 删除相册
			$url = M('picture')->where(array('p_id'=>$id))->find();
			unlink('.'.$url['p_url']);
			if(M('picture')->where(array('p_id'=>$id))->delete()){
				return 1;
			}else{
				return 0;
			}
		}
	}
?>