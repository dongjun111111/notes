<?php
namespace User\Model;
	use Think\Model;
	class SaidModel extends Model{
######################################说说操作数据模型######################################
		public function addSaid($data){
			// 添加说说
			if (M('said')->add($data)){
				return 1;
			}else{
				return 0;
			}
		}
		public function editSaid($s_id){
			// 编辑说说
			$editSaid = M('said')->where(array('s_id'=>$s_id))->find();
			if($editSaid){
				return $editSaid;
			}else{
				return 0;
			}
		}
		public function updataSaid($s_id,$data){
			// 更新说说
			if (M('said')->where(array('s_id'=>$s_id))->save($data)){
				return 1;
			}else{
				return 0;
			}
		}
		public function delSaid($s_id){
			// 删除说说
			if(M('said')->where(array('s_id'=>$s_id))->delete()){
				return 1;
			}else{
				return 0;
			}
		}
######################################说说评论操作数据模型######################################
		public function addSaidContent($data){
			if(M('said_content')->add($data)){
				return 1;
			}else{
				return 0;
			}

		}
		public function editSaidContent($s_c_id){
			// 回复
			$editSaidContent = M('said_content')->where(array('s_c_id'=>$s_c_id))->find();
			if($editSaidContent){
				return $editSaidContent;
			}else{
				return 0;
			}
		}
		public function updataSaidContent($s_c_id,$data){
			if(M('said_content')->where(array('s_c_id'=>$s_c_id))->save($data)){
				return 1;
			}else{
				return 0;
			}
		}
		public function delSaidContent($s_c_id){
			// 删除
			if(M('said_content')->where(array('s_c_id'=>$s_c_id))->delete()){
				return 1;
			}else{
				return 0;
			}
		}
	}
?>
