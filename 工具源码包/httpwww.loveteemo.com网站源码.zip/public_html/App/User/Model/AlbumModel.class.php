<?php
namespace User\Model;
	use Think\Model;
	class AlbumModel extends Model{
######################################相册操作数据模型######################################
		public function addAlbum($data){
			// 添加相册
			if(M('album')->add($data)){
				return 1;
			}else{
				return 0;
			}
		}
		public function editAlbum($id){
			// 修改相册
			$editAlbum = M('album')->where(array('al_id'=>$id))->find();
			if($editAlbum){
				return $editAlbum;
			}else{
				return 0;
			}
		}
		public function updatAlbum($id,$data){
			// 更新相册
			if(M('album')->where(array('al_id'=>$id))->save($data)){
				return 1;
			}else{
				return 0;
			}
		}
		public function delAlbum($id){
			// 删除相册
                        $url = M('album')->where(array('al_id'=>$id))->find();
			unlink('.'.$url['al_url']);
			if(M('album')->where(array('al_id'=>$id))->delete()){
				return 1;
			}else{
				return 0;
			}
		}
######################################文章评论操作数据模型######################################
		public function addAlbumContent($data){
			if(M('album_content')->add($data)){
				return 1;
			}else{
				return 0;
			}
		}	
	

public function editAlbumContent($al_c_id){
			// 回复
			$editAlbumContent = M('album_content')->where(array('al_c_id'=>$al_c_id))->find();
			if($editAlbumContent){
				return $editAlbumContent;
			}else{
				return 0;
			}
		}
		public function updataAlbumContent($al_c_id,$data){
			if(M('album_content')->where(array('al_c_id'=>$al_c_id))->save($data)){
				return 1;
			}else
				return 0;
		}
		public function delAlbumContent($al_c_id){
			// 删除
			if(M('album_content')->where(array('al_c_id'=>$al_c_id))->delete()){
				return 1;
			}else{
				return 0;
			}
		}
	}
?>