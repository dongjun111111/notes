<?php
namespace User\Model;
	use Think\Model;
	class GustbookModel extends Model{
######################################留言评论操作数据模型######################################
		public function addContent($data){
				if(M('gustbook')->add($data)){
					return 1;
				}else{
					return 0;
				}

		}
		public function editContent($c_id){
			// 回复
			$editContent = M('gustbook')->where(array('c_id'=>$c_id))->find();
			if($editContent){
				return $editContent;
			}else{
				return 0;
			}
		}
		public function updataContent($c_id,$data){
			if(M('gustbook')->where(array('c_id'=>$c_id))->save($data)){
				return 1;
			}else
				return 0;
		}
		public function delContent($c_id){
			// 删除
			if(M('gustbook')->where(array('c_id'=>$c_id))->delete()){
				return 1;
			}else{
				return 0;
			}
		}
	}
?>