<?php
namespace User\Model;
	use Think\Model;
	class TagModel extends Model{
######################################栏目操作数据模型######################################
		public function addTag($data){
			// 添加栏目操作
			if(M('tag')->add($data)){
				return 1;
			}else{
				return 0;
			}
		}
		public function editTag($id){
			// 编辑栏目读取数据
			$editTag = M('tag')->where(array('pid'=>$id))->find();
			if($editTag){
				return $editTag;
			}else{
				return 0;
			}
		}
		public function updataTag($id,$data){
			// 更新栏目信息
			if(M('tag')->where(array('pid'=>$id))->save($data)){
				return 1;
			}else{
				return 0;
			}
		}
		public function delTag($pid){
			// 删除栏目
			if(M('tag')->where(array('pid'=>$pid))->delete()){
				return 1;
			}else{
				return 0;
			}
		}
	}
?>
