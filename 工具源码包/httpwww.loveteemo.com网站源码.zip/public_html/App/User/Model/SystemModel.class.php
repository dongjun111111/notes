<?php
namespace User\Model;
	use Think\Model;
	class SystemModel extends Model{
		public function editSystem(){
			$editSystem = M('system')->where('1')->find();
			if($editSystem){
				return $editSystem;
			}else{
				return 0;
			}
		}
		public function updateSystem($data){
			M('system')->where(1)->save($data);
				return 1;
		}
		public function addVersion($data){
			M('version')->add($data);
				return 1;
		}
                public function delVersion($id){
			// 删除版本
			if(M('version')->where(array('id'=>$id))->delete()){
				return 1;
			}else{
				return 0;
			}
		}
	}
?>