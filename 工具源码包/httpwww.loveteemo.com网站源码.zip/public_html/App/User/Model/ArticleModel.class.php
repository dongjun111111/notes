<?php
namespace User\Model;
	use Think\Model;
	class ArticleModel extends Model{
######################################文章操作数据模型######################################
		public function pid(){
			// 查询栏目
			$pid = M('tag')->order('t_sort')->where(array('t_view'=>1))->select();
			return $pid;
		}
		public function addArticle($data){
			// 添加文章
			if(M('article')->add($data)){
				return 1;
			}else{
				return 0;
			}
		}
		public function editArticle($a_id){
			// 编辑文章
			$editArticle = M('article')->where(array('a_id'=>$a_id))->find();
			if($editArticle.a_id){
				return $editArticle;
			}else{
				return 0;
			}
		}
		public function updataArticle($a_id,$data){
			// 更新文章
			if (M('article')->where(array('a_id'=>$a_id))->save($data)){
				return 1;
			}else{
				return 0;
			}
		}
		public function delArticle($a_id){
			// 删除说说
			if(M('article')->where(array('a_id'=>$a_id))->delete()){
				return 1;
			}else{
				return 0;
			}
		}
######################################文章评论操作数据模型######################################	
		public function addArticleContent($data){
				if(M('article_content')->add($data)){
					return 1;
				}else{
					return 0;
				}

		}
		public function editArticleContent($a_c_id){
			// 回复
			$editArticleContent = M('article_content')->where(array('a_c_id'=>$a_c_id))->find();
			if($editArticleContent){
				return $editArticleContent;
			}else{
				return 0;
			}
		}
		public function updataArticleContent($a_c_id,$data){
			if(M('article_content')->where(array('a_c_id'=>$a_c_id))->save($data)){
				return 1;
			}else
				return 0;
		}
		public function delArticleContent($a_c_id){
			// 删除
			if(M('article_content')->where(array('a_c_id'=>$a_c_id))->delete()){
				return 1;
			}else{
				return 0;
			}
		}
	}
?>