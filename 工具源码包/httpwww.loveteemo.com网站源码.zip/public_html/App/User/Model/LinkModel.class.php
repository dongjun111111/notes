<?php
namespace User\Model;
	use Think\Model;
	class LinkModel extends Model{
		public function editLinks($l_id){
			$editLinks = M('link')->where(array('l_id'=>$l_id))->find();
			if($editLinks){
				return $editLinks;
			}else{
				return 0;
			}
		}
		public function updataLink($l_id,$data){
			if(M('link')->where(array('l_id'=>$l_id))->save($data)){
				return 1;
			}else{
				return 0;
			}
		}
		public function delLink($l_id){
			if(M('link')->where(array('l_id'=>$l_id))->delete()){
				return 1;
			}else{
				return 0;
			}
		}
	}
?>