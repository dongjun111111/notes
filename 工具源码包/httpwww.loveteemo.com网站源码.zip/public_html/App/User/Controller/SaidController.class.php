<?php
namespace User\Controller;
	use Think\Controller;
		class SaidController extends CommonController {
			public function addSaid(){
				// 发表说说
				$this->display();
			}
			public function addSaidHandle(){
				// 发表说说表单处理
				$data = array (
					's_content' => $_POST['s_content'],
					's_from'=> getOS(),
					's_view' => I('post.s_view'),
					's_hit' => I('post.s_hit'),
					's_writer' => I('post.s_writer'),
					's_time' => time(),
					's_ip' => get_client_ip(),
				);
				if(D('Said')->addSaid($data)){
					$this->success('发表说说完成！转到说说列表','saidList');
				}else{
					$this->error('发表说说失败！');
				}
			}
			public function saidList(){
				// 说说列表
				$count = M('said')->count();// 查询满足要求的总记录数
				$this->assign('count',$count);
				$Page  = new \Think\Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数
				$show  = $Page->show();// 分页显示输出
		    	$said = M('said')->limit($Page->firstRow.','.$Page->listRows)->select();
				$this->assign('saidList',$said);// 赋值数据集
				$this->assign('page',$show);// 赋值分页输出
		    	$this->display();
			}
			public function editSaid(){
				// 编辑说说
				$s_id = I('get.id');
				$editSaid = D('Said')->editSaid($s_id);
				if($editSaid  == 0){
					$this->error('参数有误，请勿在IE栏直接输入参数！');
				}else{
					$this->assign('editSaid',$editSaid);
					$this->display('addSaid');
				}	
			}
			public function editSaidHandle(){
				// 编辑说说表单处理
				$s_id = I('post.id');
				$data = array (
					's_content' => $_POST['s_content'],
					's_from'=> I('post.s_from'),
					's_view' => I('post.s_view'),
					's_hit' => I('post.s_hit'),
					's_writer' => I('post.s_writer'),
					's_time' => time(),
					's_ip' => get_client_ip(),
				);
				if(D('Said')->updataSaid($s_id,$data)){
					$this->success('修改完成！转到说说列表','saidList');
				}else{
					$this->error('修改失败！');
				}
			}
			public function delSaid(){
				// 删除说说
				$s_id = I('get.id');
				if(D('Said')->delSaid($s_id)){
					$this->redirect('User/Said/saidList');
				}else{
					$this->error('删除失败！');
				}
			}
######################################说说评论操作模型######################################
			public function saidContent(){
				// 说说评论列表
				$count = M('said_content')->count();// 查询满足要求的总记录数
				$this->assign('count',$count);
				$Page  = new \Think\Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数
				$show  = $Page->show();// 分页显示输出
		    	$said_content = M('said_content')->limit($Page->firstRow.','.$Page->listRows)->select();
				$this->assign('saidContent',$said_content);// 赋值数据集
				$this->assign('page',$show);// 赋值分页输出
				$this->display();
			}
			public function editSaidContent(){
				// 说说评论回复
				$s_c_id = I('get.id');
				$editSaidContent = D('Said')->editSaidContent($s_c_id);
				if($editSaidContent  == 0){
					$this->error('参数有误，请勿在IE栏直接输入参数！');
				}else{
					$this->assign('editSaidContent',$editSaidContent);
					$this->display();
				}
			}
			public function editSaidContentHandle(){
				$s_c_id = I('post.s_c_id');
				$data = array(
					  's_c_time' => strtotime(I('post.s_c_time')),
					  's_c_img' => I('post.s_c_img'),
					  's_c_ip' => I('post.s_c_ip'),
					  's_c_content' => I('post.s_c_content'),
					  's_c_name' => I('post.s_c_name'),
					  's_c_from' => I('post.s_c_from'),
					  's_c_email' => I('post.s_c_email'),
					  's_c_url' => I('post.s_c_url'),
					  's_c_uname' => I('post.s_c_uname'),
					  's_c_ucontent' => I('post.s_c_ucontent'),
					  's_c_utime' => time()
					);
				if(D('said')->updataSaidContent($s_c_id,$data)){
					if(I('s_c_ucontent')!=''){
				    	$content = "<div id='contentDiv' onmouseover='getTop().stopPropagation(event);' onclick='getTop().preSwapLink(event, 'spam', 'ZC2914-IKsXmwzBblF9dlgNWDI9L54');' style='position:relative;font-size:14px;height:auto;padding:15px 15px 10px 15px;z-index:1;zoom:1;line-height:1.7;overflow:hidden;' class='body'>    <div class='' id='qm_con_body'><div style='' id='mailContentContainer' class='qmbox qm_con_body_content'>
										<div style='border:1px double #f60;'>
										<div style='background:#f60; padding:10px 10px 10px 20px; color:#FFF; font-size:16px;'>
										您在 <a style='text-decoration:none;color:#fff;' href='http://www.loveteemo.com' target='_blank'>LoveTeemo博客</a> 说说上留言有了回复：
										</div>
										<div style=' padding:10px 10px 5px 20px; font-size:12px'>亲爱的 [ ".I("post.s_c_name")." ] ：您好!</div>
										<div style=' padding:5px 10px 10px 20px; font-size:12px'>您曾在 [ LoveTeemo博客 ] 留言说道：</div>
										<div style='padding:10px 10px 10px 10px; font-size:12px; background:#f2f2f2;border:1px double #ccc; margin:0px 15px 0px 15px; line-height:25px;'>".I("post.s_c_content")."</div>
										<div style=' padding:10px 10px 10px 20px; font-size:12px'>[ ".I("post.s_c_uname")." ] 给您的回复如下：</div>
										<div style='padding:10px 10px 10px 10px; font-size:12px; background:#f2f2f2;border:1px double #ccc;margin:0px 15px 0px 15px; line-height:25px;'>".I("post.s_c_ucontent")."</div>
										<div style=' padding:10px 10px 10px 20px; font-size:12px'><strong>温馨提示</strong> 本邮件由系统自动发出，请勿直接回复！</div>
										</div></div></div>
										<!-- -->
										<style>#mailContentContainer .txt {height:auto;}</style>  
									</div>";
				    	SendMail(I('post.s_c_email'),'您在LoveTeemo上的评论有了新的回复',$content);
						$this->success('回复完成，已通过邮件发送给对方！','saidContent');}
					else{
						$this->success('回复完成，跳到说说评论列表','saidContent');
					}
				}else{
					$this->error('回复失败!');
				}
			}
			public function delSaidContent(){
				// 删除说说评论
				$s_c_id = I('get.id');
				if(D('said')->delSaidContent($s_c_id)){
					$this->redirect('User/Said/saidContent');
				}else{
					$this->error('删除失败！');
				}
			}
		}
?>