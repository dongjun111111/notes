<?php
namespace User\Controller;
	use Think\Controller;
		class IndexController extends CommonController {
		    public function index(){
		    	// 首页模型
		    	$s_count = M('said')->count();
			    $a_count = M('article')->count();
			    $c_count = M('gustbook')->count();
			    $al_count = M('Album')->count();
			    $l_count = M('link')->count();
		    	$data = array(
			    	's_count' => $s_count,
			    	'a_count' => $a_count,
			    	'c_count' => $c_count,
			    	'al_count' => $al_count,
			    	'l_count' => $l_count
		    	);
		    	$this->assign('data',$data);
		    	$version = M('version')->order('id desc')->limit(0,3)->select();
				$this->assign('version',$version);
		    	$this->display();
		    }
			public function loginout(){
		    	// 退出
				// 清空SESSION
				session(null);
				// 转跳登陆页面
				$this->redirect('Login/index');
			}


	}