<?php
namespace User\Controller;
	use Think\Controller;
		class PictureController extends CommonController {
######################################图片操作模型######################################			
			public function addPicture(){
				// 发表文章
		    	$aid = D('Picture')->aid();
		    	$this->assign('al_id',$aid);
				$this->display();
			}
			public function addPictureHandle(){
				$upload = new \Think\Upload();// 实例化上传类
				$upload->maxSize   =     3145728 ;// 设置附件上传大小
				$upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
				$upload->rootPath  =      'Upload/Album/'; // 设置附件上传根目录
				$upload->saveName = 'time';
				$upload->subName  = 'album-'.I('post.al_id');
				// 上传文件 
				$info   =   $upload->upload();
					if(!$info) {// 上传错误提示错误信息
					    $this->error('上传文件错误！');
					}else{// 上传成功 获取上传文件信息
					    foreach($info as $file){
					        $url = "/Upload/Album/". $file['savepath'].$file['savename'];
					    }
					}
				// 添加相册表单操作
				$data = array (
					// 拼装数组
					'al_id'	=>	I('post.al_id'),
					'p_view'=>I('post.p_view'),
					'p_url'	=>	$url,
				);
				if(D('Picture')->addPicture($data)){
					$this->success('添加图片完成！转调到图片列表','pictureList');
				}else{
					$this->error('添加图片失败！');
				}
			}
			public function pictureList(){
				// 相册列表
		    	$pictureList= D('Picture')->pictureList();
		    	$this->assign('pictureList',$pictureList);
		    	$this->display();
			}
			public function editPicture(){
				// 编辑相册
				$id = I('get.id');
		    	$aid = D('Picture')->aid();	    	
		    	$this->assign('al_id',$aid);
				$editPicture = D('Picture')->editPicture($id);
				if($editPicture  == 0){
					$this->error('图片不存在！');
				}else{
					$this->assign('editPicture',$editPicture);
					$this->display('addPicture');
				}	
			}
			public function editPictureHandle(){
				$id = I('post.id');
				$data = array(
					'al_id' =>	 I('post.al_id'),
					'p_view'=>	 I('post.p_view'),
					);
				if(D('Picture')->updataPicture($id,$data)){
					$this->success('修改图片完成！转调到图片列表','pictureList');
				}else{
					$this->success('图片未做修改！转调到图片列表','pictureList');
				}
			}	
			public function delPicture(){
				$id = I('get.id');
				if(D('Picture')->delPicture($id)){
					$this->redirect('User/Picture/pictureList');
				}else{
					$this->error('删除失败');
				}
			}
		}
?>