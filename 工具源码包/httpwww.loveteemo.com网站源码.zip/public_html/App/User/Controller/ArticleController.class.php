<?php
namespace User\Controller;
	use Think\Controller;
		class ArticleController extends CommonController {		
			public function addArticle(){
				// 发表文章
		    	$pid = D('Article')->pid();
		    	$this->assign('t_id',$pid);
				$this->display();
			}
			public function addArticleHandle(){
				// 发表文章表单操作
				$data = array (
					'a_title' => I('post.a_title'),
					'pid' => I('post.pid'),
					'a_keyword' => I('post.a_keyword'),
					'a_remark' => I('post.a_remark'),
					'a_content' => $_POST['a_content'],
					'a_from'=> getOS(),
					'a_view' => I('post.a_view'),
					'a_hit' => I('post.a_hit'),
					'a_writer' => I('post.a_writer'),
					'a_time' => time(),
					'a_ip' => get_client_ip(),
				);//var_dump($data);die;
				if(D('Article')->addArticle($data)){
					$this->success('发表文章完成！转调到文章列表','articleList');
				}else{
					$this->error('发表文章失败！');
				}
			}
			public function articleList(){
				// 文章列表
				$count = M('article')->count();// 查询满足要求的总记录数
				$this->assign('count',$count);
				$Page  = new \Think\Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数
				$show  = $Page->show();// 分页显示输出
		    	$article = M('article')->order('a_time desc')->limit($Page->firstRow.','.$Page->listRows)->select();
				$this->assign('articleList',$article);// 赋值数据集
				$this->assign('page',$show);// 赋值分页输出
		    	$this->display();
			}
			public function editArticle(){
				// 编辑文章
				$a_id = I('get.id');
		    	$pid = D('Article')->pid();
		    	$this->assign('t_id',$pid);
				$editArticle = D('Article')->editArticle($a_id);
				if($editArticle  == 0){
					$this->error('参数有误，请勿在IE栏直接输入参数！');
				}else{
					$this->assign('editArticle',$editArticle);
					$this->display('addArticle');
				}
			}
			public function editArticleHandle(){
				// 修改文章表单处理
				$a_id = I('post.id');
				$data = array (
					'a_title' => I('post.a_title'),
					'pid' => I('post.pid'),
					'a_keyword' => I('post.a_keyword'),
					'a_remark' => I('post.a_remark'),
					'a_content' => $_POST['a_content'],
					'a_from'=> getOS(),
					'a_view' => I('post.a_view'),
					'a_hit' => I('post.a_hit'),
					'a_writer' => I('post.a_writer'),
					'a_time' => time(),
					'a_ip' => get_client_ip(),
				);
				if(D('Article')->updataArticle($a_id,$data)){
					$this->success('修改完成！转调到文章列表','articleList');
				}else{
					$this->error('修改失败！');
				}
			}
			public function delArticle(){
				// 删除文章
				$a_id = I('get.id');
				if(D('Article')->delArticle($a_id)){
					$this->redirect('User/Article/articleList');
				}else{
					$this->error('删除失败！');
				}
			}
######################################文章评论操作模型######################################
			public function articleContent(){
				// 文章评论列表
				$count = M('article_content')->count();// 查询满足要求的总记录数
				$this->assign('count',$count);
				$Page  = new \Think\Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数
				$show  = $Page->show();// 分页显示输出
		    	$article_content = M('article_content')->order('a_c_time desc')->limit($Page->firstRow.','.$Page->listRows)->select();
				$this->assign('articleContent',$article_content);// 赋值数据集
				$this->assign('page',$show);// 赋值分页输出
				$this->display();
			}
			public function editArticleContent(){
				// 说说评论回复
				$a_c_id = I('get.id');
				$editArticleContent = D('Article')->editArticleContent($a_c_id);
				if($editArticleContent  == 0){
					$this->error('参数有误，请勿在IE栏直接输入参数！');
				}else{
//var_dump($editArticleContent );die;
					$this->assign('editArticleContent',$editArticleContent);
					$this->display();
				}
			}
			public function editArticleContentHandle(){
				$a_c_id = I('post.a_c_id');
				$data = array(
					  'a_c_time' => strtotime(I('post.a_c_time')),
					  'a_c_ip' => I('post.a_c_ip'),
					  'a_c_img' => I('post.a_c_img'),
					  'a_c_content' => I('post.a_c_content'),
					  'a_c_name' => I('post.a_c_name'),
					  'a_c_from' => I('post.a_c_from'),
					  'a_c_email' => I('post.a_c_email'),
					  'a_c_url' => I('post.a_c_url'),
					  'a_c_uname' => I('post.a_c_uname'),
					  'a_c_ucontent' => I('post.a_c_ucontent'),
					  'a_c_utime' => time()
					);
				if(D('article')->updataArticleContent($a_c_id,$data)){
					if(I('a_c_ucontent')!=''){
			    	$content = "<div id='contentDiv' onmouseover='getTop().stopPropagation(event);' onclick='getTop().preSwapLink(event, 'spam', 'ZC2914-IKsXmwzBblF9dlgNWDI9L54');' style='position:relative;font-size:14px;height:auto;padding:15px 15px 10px 15px;z-index:1;zoom:1;line-height:1.7;overflow:hidden;' class='body'>    <div class='' id='qm_con_body'><div style='' id='mailContentContainer' class='qmbox qm_con_body_content'>
									<div style='border:1px double #f60;'>
									<div style='background:#f60; padding:10px 10px 10px 20px; color:#FFF; font-size:16px;'>
									您在 <a style='text-decoration:none;color:#fff;' href='http://www.loveteemo.com' target='_blank'>LoveTeemo博客</a> 文章上留言有了回复：
									</div>
									<div style=' padding:10px 10px 5px 20px; font-size:12px'>亲爱的 [ ".I("post.a_c_name")." ] ：您好!</div>
									<div style=' padding:5px 10px 10px 20px; font-size:12px'>您曾在 [ LoveTeemo博客 ] 留言说道：</div>
									<div style='padding:10px 10px 10px 10px; font-size:12px; background:#f2f2f2;border:1px double #ccc; margin:0px 15px 0px 15px; line-height:25px;'>".I("post.a_c_content")."</div>
									<div style=' padding:10px 10px 10px 20px; font-size:12px'>[ ".I("post.a_c_uname")." ] 给您的回复如下：</div>
									<div style='padding:10px 10px 10px 10px; font-size:12px; background:#f2f2f2;border:1px double #ccc;margin:0px 15px 0px 15px; line-height:25px;'>".I("post.a_c_ucontent")."</div>
									<div style=' padding:10px 10px 10px 20px; font-size:12px'><strong>温馨提示</strong> 本邮件由系统自动发出，请勿直接回复！</div>
									</div></div></div>
									<!-- -->
									<style>#mailContentContainer .txt {height:auto;}</style>  
								</div>";
			    	SendMail(I('post.a_c_email'),'您在LoveTeemo上的评论有了新的回复',$content);
			    		$this->success('回复完成，已通过邮件发送给对方！','articleContent');
					}else{
						$this->success('回复完成，转到文章评论页！','articleContent');
					}
					
				}else{
					$this->error('回复失败!');
				}
			}
			public function delArticleContent(){
				// 删除说说评论
				$a_c_id = I('get.id');
				if(D('article')->delArticleContent($a_c_id)){
					$this->redirect('User/Article/articleContent');
				}else{
					$this->error('删除失败！');
				}
			}
		}
?>