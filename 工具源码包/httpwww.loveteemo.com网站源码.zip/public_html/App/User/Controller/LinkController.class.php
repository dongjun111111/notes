<?php
namespace User\Controller;
	use Think\Controller;
		class LinkController extends CommonController{
			public function editLink(){
				// 友情连接列表
                $count = M('link')->count();// 查询满足要求的总记录数
                $this->assign('count',$count);
                $Page  = new \Think\Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数
                $show  = $Page->show();// 分页显示输出
                $link = M('link')->limit($Page->firstRow.','.$Page->listRows)->select();
                $this->assign('link',$link);// 赋值数据集
                $this->assign('page',$show);// 赋值分页输出
                $this->display();
			}
			public function editLinks(){
				$l_id = I('get.id');
				$editLinks = D('Link')->editLinks($l_id);
				if($editLinks  == 0){
					$this->error('参数有误，请勿在IE栏直接输入参数！');
				}else{
					$this->assign('editLinks',$editLinks);
					$this->display();
				}
			}
			public function editLinksHandle(){
				$l_id = I('post.l_id');
                $data = array(
                      'l_name' => I('post.l_name'),
                      'l_time' => strtotime(I('post.l_time')),
                      'l_ip' => I('post.c_ip'),
                      'l_remark' => I('post.l_remark'),
                      'l_url' => I('post.l_url'),
                      'l_sort' => I('post.l_sort'),
                      'l_img' => I('post.l_img'),
                      'l_level' => I('post.l_level'),
                      'l_email' => I('post.l_email'),
                      'l_view' => I('post.l_view'),
                      'l_uname' => I('post.l_uname'),
                      'l_ucontent' => I('post.l_ucontent'),
                      'l_utime' => time()
                    );
                if(D('link')->updataLink($l_id,$data)){
                    if(I('l_ucontent')!=''){
                    $content = "<div id='contentDiv' onmouseover='getTop().stopPropagation(event);' onclick='getTop().preSwapLink(event, 'spam', 'ZC2914-IKsXmwzBblF9dlgNWDI9L54');' style='position:relative;font-size:14px;height:auto;padding:15px 15px 10px 15px;z-index:1;zoom:1;line-height:1.7;overflow:hidden;' class='body'>    <div class='' id='qm_con_body'><div style='' id='mailContentContainer' class='qmbox qm_con_body_content'>
                                    <div style='border:1px double #f60;'>
                                    <div style='background:#f60; padding:10px 10px 10px 20px; color:#FFF; font-size:16px;'>
                                    您在 <a style='text-decoration:none;color:#fff;' href='http://www.loveteemo.com' target='_blank'>LoveTeemo博客</a> 友情链接上留言有了回复：
                                    </div>
                                    <div style=' padding:10px 10px 5px 20px; font-size:12px'>亲爱的 [ ".I("post.l_name")." ] ：您好!</div>
                                    <div style=' padding:5px 10px 10px 20px; font-size:12px'>您曾在 [ LoveTeemo博客 ] 申请友链说道：</div>
                                    <div style='padding:10px 10px 10px 10px; font-size:12px; background:#f2f2f2;border:1px double #ccc; margin:0px 15px 0px 15px; line-height:25px;'>".I("post.l_remark")."</div>
                                    <div style=' padding:10px 10px 10px 20px; font-size:12px'>[ ".I("post.l_uname")." ] 给您的回复如下：</div>
                                    <div style='padding:10px 10px 10px 10px; font-size:12px; background:#f2f2f2;border:1px double #ccc;margin:0px 15px 0px 15px; line-height:25px;'>".I("post.l_ucontent")."</div>
                                    <div style=' padding:10px 10px 10px 20px; font-size:12px'><strong>温馨提示</strong> 本邮件由系统自动发出，请勿直接回复！</div>
                                    </div></div></div>
                                    <!-- -->
                                    <style>#mailContentContainer .txt {height:auto;}</style>  
                                </div>";
                    SendMail(I('post.l_email'),'您在LoveTeemo上申请友链有了新的回复',$content);
                        $this->success('回复完成，已通过邮件发送给对方！','editLink');
                    }else{
                        $this->success('回复完成，转到文章评论页！','editLink');
                    }
                    
                }else{
                    $this->error('回复失败!');
                }
			}
			public function delLink(){
				$l_id = I('get.id');
				if(D('Link')->delLink($l_id)){
					$this->redirect('User/Link/editLink');
				}else{
					$this->error('删除失败！');
				}
			}
		}
?>
