<?php
	namespace User\Controller;
	use Think\Controller;
	class CommonController extends Controller{
		public function _initialize(){
			// 自动运行函数 检查SESSION是否存在
			if(!isset($_SESSION['uid'])){
				// SESSION 不存在则转调到登录界面
				$this->redirect('User/Login/index');
			}
                    // 分配版权
 		    $this->copy = M('system')->where('1')->getField('copy');
	            // SESSION 存在则给存入SESSION的值传到首页
		    $this->user = SESSION('user');
		    $this->name = SESSION('name');
		}
	}
	
?> 