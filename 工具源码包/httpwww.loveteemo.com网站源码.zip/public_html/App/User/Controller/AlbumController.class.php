<?php
namespace User\Controller;
	use Think\Controller;
		class AlbumController extends CommonController {
######################################相册操作模型######################################
			public function addAlbum(){
				// 添加用户
		    	$this->display();
			}
			public function addAlbumHandle(){
				$upload = new \Think\Upload();// 实例化上传类
				$upload->maxSize   =     3145728 ;// 设置附件上传大小
				$upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
				$upload->rootPath  =      'Upload/Album/'; // 设置附件上传根目录
				$upload->saveName = 'time';
				$upload->autoSub  = false;
				// 上传文件 
				$info   =   $upload->upload();
					if(!$info) {// 上传错误提示错误信息
					    $this->error('上传文件错误！');
					}else{// 上传成功 获取上传文件信息
					    foreach($info as $file){
					        $url = "/Upload/Album/".$file['savename'];
					    }
					}
				// 添加相册表单操作
				$data = array (
					// 拼装数组
					'al_name'	=>	I('post.al_name'),
					'al_hit'	=>	I('post.al_hit'),
					'al_view'	=>	I('post.al_view'),
					'al_star'	=>	I('post.al_star'),
					'al_time'	=>	time(),
					'al_url'	=>	$url,
				);
				if(D('Album')->addAlbum($data)){
					$this->success('添加相册完成！转调到相册列表','albumList');
				}else{
					$this->error('添加相册失败！');
				}
			}
			public function albumList(){
				// 相册列表
		    	// 分页类
				$count = M('album')->count();// 查询满足要求的总记录数
				$this->assign('count',$count);
				$Page  = new \Think\Page($count,5);// 实例化分页类 传入总记录数和每页显示的记录数
				$show  = $Page->show();// 分页显示输出
		    	$album = M('album')->limit($Page->firstRow.','.$Page->listRows)->select();
				$this->assign('albumList',$album);// 赋值数据集
				$this->assign('page',$show);// 赋值分页输出
		    	$this->display();
			}
			public function editAlbum(){
				// 编辑相册
				$id = I('get.id');
				$editAlbum = D('Album')->editAlbum($id);
				if($editAlbum  == 0){
					$this->error('用户不存在！');
				}else{
					$this->assign('editAlbum',$editAlbum);
					$this->display('addAlbum');
				}	
			}
			public function editAlbumHandle(){
				// 编辑用户表单处理
				$id = I('post.id');
				if($_FILES['file']['name']==''){
					$url = I('post.al_url');
				}else{
					$upload = new \Think\Upload();// 实例化上传类
					$upload->maxSize   =     3145728 ;// 设置附件上传大小
					$upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
					$upload->rootPath  =      'Upload/Album/'; // 设置附件上传根目录
					$upload->saveName = 'time';
					// 上传文件 
					$info   =   $upload->upload();
						if(!$info) {// 上传错误提示错误信息
						    $this->error('上传文件错误！');
						}else{// 上传成功 获取上传文件信息
						    foreach($info as $file){
						        $url = "/Upload/Album/". $file['savepath'].$file['savename'];
						    }
						}
					}
				// 添加相册表单操作
				$data = array (
					// 拼装数组
					'al_name'	=>	I('post.al_name'),
					'al_hit'	=>	I('post.al_hit'),
					'al_view'	=>	I('post.al_view'),
					'al_star'	=>	I('post.al_star'),
					'al_time'	=>	time(),
					'al_url'	=>	$url,
				);
				if(D('Album')->updatAlbum($id,$data)){
					$this->success('修改相册完成！转调到相册列表','albumList');
				}else{
					$this->error('修改相册失败！');
				}
			}
			public function delAlbum(){
				$id = I('get.id');
				if(D('Album')->delAlbum($id)){
					$this->redirect('User/Album/albumList');
				}else{
					$this->error('删除失败！');
				}
			}
######################################相册评论操作模型######################################
			public function albumContent(){
				// 文章评论列表
				$count = M('album_content')->count();// 查询满足要求的总记录数
				$this->assign('count',$count);
				$Page  = new \Think\Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数
				$show  = $Page->show();// 分页显示输出
		    	$album_content = M('album_content')->limit($Page->firstRow.','.$Page->listRows)->select();
				$this->assign('albumContent',$album_content);// 赋值数据集
				$this->assign('page',$show);// 赋值分页输出
				$this->display();
			}
			public function editAlbumContent(){
				// 说说评论回复
				$al_c_id = I('get.id');
				$editAlbumContent = D('Album')->editAlbumContent($al_c_id);
				if($editAlbumContent  == 0){
					$this->error('参数有误，请勿在IE栏直接输入参数！');
				}else{
					$this->assign('editAlbumContent',$editAlbumContent);
					$this->display();
				}
			}
			public function editAlbumContentHandle(){
				$al_c_id = I('post.al_c_id');
				$data = array(
					  'al_c_time' => strtotime(I('post.al_c_time')),
					  'al_c_ip' => I('post.al_c_ip'),
					  'al_c_img' => I('post.al_c_img'),
					  'al_c_content' => I('post.al_c_content'),
					  'al_c_name' => I('post.al_c_name'),
					  'al_c_from' => I('post.al_c_from'),
					  'al_c_email' => I('post.al_c_email'),
					  'al_c_url' => I('post.al_c_url'),
					  'al_c_uname' => I('post.al_c_uname'),
					  'al_c_ucontent' => I('post.al_c_ucontent'),
					  'al_c_utime' => time()
					);
				if(D('album')->updataAlbumContent($al_c_id,$data)){
					if(I('al_c_ucontent')!=''){
			    	$content = "<div id='contentDiv' onmouseover='getTop().stopPropagation(event);' onclick='getTop().preSwapLink(event, 'spam', 'ZC2914-IKsXmwzBblF9dlgNWDI9L54');' style='position:relative;font-size:14px;height:auto;padding:15px 15px 10px 15px;z-index:1;zoom:1;line-height:1.7;overflow:hidden;' class='body'>    <div class='' id='qm_con_body'><div style='' id='mailContentContainer' class='qmbox qm_con_body_content'>
									<div style='border:1px double #f60;'>
									<div style='background:#f60; padding:10px 10px 10px 20px; color:#FFF; font-size:16px;'>
									您在 <a style='text-decoration:none;color:#fff;' href='http://www.loveteemo.com' target='_blank'>LoveTeemo博客</a> 相册上留言有了回复：
									</div>
									<div style=' padding:10px 10px 5px 20px; font-size:12px'>亲爱的 [ ".I("post.al_c_name")." ] ：您好!</div>
									<div style=' padding:5px 10px 10px 20px; font-size:12px'>您曾在 [ LoveTeemo博客 ] 留言说道：</div>
									<div style='padding:10px 10px 10px 10px; font-size:12px; background:#f2f2f2;border:1px double #ccc; margin:0px 15px 0px 15px; line-height:25px;'>".I("post.al_c_content")."</div>
									<div style=' padding:10px 10px 10px 20px; font-size:12px'>[ ".I("post.al_c_uname")." ] 给您的回复如下：</div>
									<div style='padding:10px 10px 10px 10px; font-size:12px; background:#f2f2f2;border:1px double #ccc;margin:0px 15px 0px 15px; line-height:25px;'>".I("post.al_c_ucontent")."</div>
									<div style=' padding:10px 10px 10px 20px; font-size:12px'><strong>温馨提示</strong> 本邮件由系统自动发出，请勿直接回复！</div>
									</div></div></div>
									<!-- -->
									<style>#mailContentContainer .txt {height:auto;}</style>  
								</div>";
			    	SendMail(I('post.al_c_email'),'您在LoveTeemo上的评论有了新的回复',$content);
			    		$this->success('回复完成，已通过邮件发送给对方！','albumContent');
					}else{
						$this->success('回复完成，转到文章评论页！','albumContent');
					}
					
				}else{
					$this->error('回复失败!');
				}
			}
			public function delAlbumContent(){
				// 删除说说评论
				$al_c_id = I('get.id');
				if(D('album')->delAlbumContent($al_c_id)){
					$this->redirect('User/Album/albumContent');
				}else{
					$this->error('删除失败！');
				}
			}
		}
?>