<?php
namespace User\Controller;
	use Think\Controller;
		class VersionController extends CommonController {
			public function index(){
				$data = M('version')->order('id desc')->limit(0,10)->select();
				$this->assign('data',$data);
				$this->display();
			}
			public function editVersion(){
				$this->display();
			}
			public function editVersionHandle(){
				$data = array(
				  'title' 	=>  I('post.title'),
				  'content' =>  I('post.content'),
				  'author' 	=>  I('post.author'),
				  'version' =>  I('post.version'),
				  'time'	=>  time(),
				  'ip'		=>	get_client_ip()
				);
				if(D('System')->addVersion($data)){
					$this->success('发布新版本成功!','index');
				}else{
					$this->error('发布新版本失败！');
				}
			}
                        public function delVersion(){
				$id = I('get.id');
				if(D('System')->delVersion($id)){
					$this->redirect('index');
				}else{
					$this->error('删除失败！');
				}
			}
		}
?>