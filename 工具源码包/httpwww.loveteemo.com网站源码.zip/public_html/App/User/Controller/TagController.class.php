<?php
namespace User\Controller;
	use Think\Controller;
		class TagController extends CommonController {
######################################栏目操作模型######################################
			public function addTag(){
				// 添加栏目
		    	$this->display();
			}
			public function addTagHandle(){
				// 添加栏目表单操作
				$data = array(
					// 拼装数据存入数据库
					't_name'	=>	I('post.t_name'),
					't_remark'	=>	I('post.t_remark'),
					't_view'	=>	I('post.t_sort'),
					't_open'	=>	I('post.t_open'),
					't_view'	=>	I('post.t_view'),
					't_time'	=>	time(),
				);
				if(D('Tag')->addTag($data)){
					$this->success('添加栏目完成！转调到栏目列表','tagList');
				}else{
					$this->error('添加栏目失败');
				}
			}
			public function tagList(){
				// 栏目列表
				$this->user = SESSION('user');
		    	$this->name = SESSION('name');
		    	// 分页类
				$count = M('tag')->count();// 查询满足要求的总记录数
				$this->assign('count',$count);
				$Page  = new \Think\Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数
				$show  = $Page->show();// 分页显示输出
		    	$tag = M('tag')->limit($Page->firstRow.','.$Page->listRows)->order('pid')->select();
				$this->assign('tagList',$tag);// 赋值数据集
				$this->assign('page',$show);// 赋值分页输出
		    	$this->display();
			}
			public function editTag(){
				// 编辑用户
		    	$id = I('get.id');
				$editTag = D('Tag')->editTag($id);
				if($editTag  == 0){
					$this->error('用户不存在！');
				}else{
					$this->assign('editTag',$editTag);
					$this->display('addTag');
				}
			}
			public function editTagHandle(){
				// 编辑用户表单处理
				$id = I('post.id');
				$data = array(
					// 拼装数据存入数据库
					't_name'	=>	I('post.t_name'),
					't_remark'	=>	I('post.t_remark'),
					't_sort'	=>	I('post.t_sort'),
					't_open'	=>	I('post.t_open'),
					't_view'	=>	I('post.t_view'),
					't_time'	=>	time(),
				);
				if(D('Tag')->updataTag($id,$data)){
					$this->success('修改完成！转调到栏目列表','tagList');
				}else{
					$this->error('修改失败！请检查输入的数据');
				}
			}
			public function delTag(){
				// 删除栏目
				$pid = I('get.id');
				if(D('Tag')->delTag($pid)){
					$this->redirect('User/Tag/tagList');
				}else{
					$this->error('删除失败！');
				}
			}
		}
?>