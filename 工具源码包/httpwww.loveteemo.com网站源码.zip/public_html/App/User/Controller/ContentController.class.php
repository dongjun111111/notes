<?php
namespace User\Controller;
    use Think\Controller;
        class ContentController extends CommonController {
        ######################################相册评论操作模型######################################
            public function Content(){
                // 评论列表
                $count = M('gustbook')->count();// 查询满足要求的总记录数
                $this->assign('count',$count);
                $Page  = new \Think\Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数
                $show  = $Page->show();// 分页显示输出
                $content = M('gustbook')->limit($Page->firstRow.','.$Page->listRows)->select();
                $this->assign('content',$content);// 赋值数据集
                $this->assign('page',$show);// 赋值分页输出
                $this->display();
            }
            public function editContent(){
                // 评论回复
                $c_id = I('get.id');
                $editContent = D('gustbook')->editContent($c_id);
                if($editContent  == 0){
                    $this->error('参数有误，请勿在IE栏直接输入参数！');
                }else{
                    $this->assign('editContent',$editContent);
                    $this->display();
                }
            }
            public function editContentHandle(){
                $c_id = I('post.c_id');
                $data = array(
                      'c_time' => strtotime(I('post.c_time')),
                      'c_ip' => I('post.c_ip'),
                      'c_content' => I('post.c_content'),
                      'c_name' => I('post.c_name'),
                      'c_from' => I('post.c_from'),
                      'c_email' => I('post.c_email'),
                      'c_url' => I('post.c_url'),
                      'c_uname' => I('post.c_uname'),
                      'c_ucontent' => I('post.c_ucontent'),
                      'c_utime' => time()
                    );
                if(D('gustbook')->updataContent($c_id,$data)){
                    if(I('c_ucontent')!=''){
                    $content = "<div id='contentDiv' onmouseover='getTop().stopPropagation(event);' onclick='getTop().preSwapLink(event, 'spam', 'ZC2914-IKsXmwzBblF9dlgNWDI9L54');' style='position:relative;font-size:14px;height:auto;padding:15px 15px 10px 15px;z-index:1;zoom:1;line-height:1.7;overflow:hidden;' class='body'>    <div class='' id='qm_con_body'><div style='' id='mailContentContainer' class='qmbox qm_con_body_content'>
                                    <div style='border:1px double #f60;'>
                                    <div style='background:#f60; padding:10px 10px 10px 20px; color:#FFF; font-size:16px;'>
                                    您在 <a style='text-decoration:none;color:#fff;' href='http://www.loveteemo.com' target='_blank'>LoveTeemo博客</a> 留言版上留言有了回复：
                                    </div>
                                    <div style=' padding:10px 10px 5px 20px; font-size:12px'>亲爱的 [ ".I("post.c_name")." ] ：您好!</div>
                                    <div style=' padding:5px 10px 10px 20px; font-size:12px'>您曾在 [ LoveTeemo博客 ] 留言说道：</div>
                                    <div style='padding:10px 10px 10px 10px; font-size:12px; background:#f2f2f2;border:1px double #ccc; margin:0px 15px 0px 15px; line-height:25px;'>".I("post.c_content")."</div>
                                    <div style=' padding:10px 10px 10px 20px; font-size:12px'>[ ".I("post.c_uname")." ] 给您的回复如下：</div>
                                    <div style='padding:10px 10px 10px 10px; font-size:12px; background:#f2f2f2;border:1px double #ccc;margin:0px 15px 0px 15px; line-height:25px;'>".I("post.c_ucontent")."</div>
                                    <div style=' padding:10px 10px 10px 20px; font-size:12px'><strong>温馨提示</strong> 本邮件由系统自动发出，请勿直接回复！</div>
                                    </div></div></div>
                                    <!-- -->
                                    <style>#mailContentContainer .txt {height:auto;}</style>  
                                </div>";
                    SendMail(I('post.c_email'),'您在LoveTeemo上的评论有了新的回复',$content);
                        $this->success('回复完成，已通过邮件发送给对方！','content');
                    }else{
                        $this->success('回复完成，转到文章评论页！','content');
                    }
                    
                }else{
                    $this->error('回复失败!');
                }
            }
            public function delContent(){
                // 删除说说评论
                $c_id = I('get.id');
                if(D('gustbook')->delContent($c_id)){
                    $this->redirect('User/Content/content');
                }else{
                    $this->error('删除失败！');
                }
            }
    }
?>