<?php
namespace User\Controller;
	use Think\Controller;
		class UserController extends CommonController {
######################################用户操作模型######################################
			public function addUser(){
				// 添加用户
		    	$this->display();
			}
			public function addUserHandle(){
				// 添加用户表单操作
				$data = array (
					// 拼装数组
					'name'		=>	I('post.name'),
					'password'	=>	I('post.password'),
					'user'		=>	I('post.user'),
					'class'		=>	I('post.class'),
					'last_time'	=>	time(),
					'ip' 		=>	get_client_ip(),
				);
				if(D('User')->addUser($data)){
					$this->success('添加用户完成！转调到用户列表','userList');
				}else{
					$this->error('添加用户失败！');
				}
			}
			public function userList(){
				// 用户列表
		    	// 分页类
				$count = M('user')->count();// 查询满足要求的总记录数
				$this->assign('count',$count);
				$Page  = new \Think\Page($count,5);// 实例化分页类 传入总记录数和每页显示的记录数
				$show  = $Page->show();// 分页显示输出
		    	$user = M('user')->limit($Page->firstRow.','.$Page->listRows)->select();
				$this->assign('userList',$user);// 赋值数据集
				$this->assign('page',$show);// 赋值分页输出
		    	$this->display();
			}
			public function editUser(){
				// 编辑用户
				$id = I('get.id');
				$editUser = D('User')->editUser($id);
				if($editUser  == 0){
					$this->error('用户不存在！');
				}else{
					$this->assign('editUser',$editUser);
					$this->display('addUser');
				}	
			}
			public function editUserHandle(){
				// 编辑用户表单处理
				$id = I('post.id');
				$data = array (
					// 拼装数组
					'name'		=>	I('post.name'),
					'password'	=>	I('post.password'),
					'user'		=>	I('post.user'),
					'class'		=>	I('post.class'),
					'last_time'	=>	time(),
					'ip' 		=>	get_client_ip(),
				);
				if(D('user')->updataUser($id,$data)){
					if(I('post.name') ==  $row){
						$this->success('修改完成,请重新登陆','loginout');
					}else{
						$this->success('修改完成！转跳到用户列表页','userList');
					}
				}else{
					$this->error('修改失败！请检查输入的数据');
				}
			}
			public function delUser(){
				$id = I('get.id');
				if(D('user')->delUser($id)){
					$this->redirect('User/User/userList');
				}else{
					$this->error('删除失败');
				}
			}
		}
?>