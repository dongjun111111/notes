<?php
namespace User\Controller;
	use Think\Controller;
		class SystemController extends CommonController {
			public function index(){
				$editSystem = D('System')->editSystem();
				if($editSystem  == 0){
				}else{
					$this->assign('editSystem',$editSystem);
				}
				$this->display();
			}
			public function editSystem(){
				$data = array(
					  'title' => I('post.title'),
					  'title_2' =>  I('post.title_2'),
					  'keyword' => I('post.keyword'),
					  'remark' =>  I('post.remark'),
					  'author' => I('post.author'),
					  'time' => I('post.time'),
					  'icp' => I('post.icp'),
					  'copy' =>  I('post.copy'),
					  'footer' =>  $_POST['footer'],
					  'hit' =>  I('post.hit')
					);
				if(D('System')->updateSystem($data)){
					$this->success('更新完成','index');
				}else{
					$this->error('更新失败！');
				}
			}
			public function setting(){
				$data = array(
					'MAIL_HOST' 	=> C('MAIL_HOST'),
					'MAIL_SMTP' 	=> C('MAIL_SMTP'),
					'MAIL_SMTPAUTH' => C('MAIL_SMTPAUTH'),
				    'MAIL_USERNAME' => C('MAIL_USERNAME'),
				    'MAIL_PASSWORD' => C('MAIL_PASSWORD'),
				    'MAIL_SECURE'   => C('MAIL_SECURE'),
				    'MAIL_CHARSET'  => C('MAIL_CHARSET'),
				    'MAIL_ISHTML'   => C('MAIL_ISHTML'),
				    'NAME'    		=> C('NAME'),
				    'LANG'    		=> C('LANG'),
				    'CHARSET'    	=> C('CHARSET'),
				    'REMARK'    	=> C('REMARK'),
					);
				$this->assign('setting',$data);
				$this->display();
			}
			public function editSetting(){
				$path = 'App/User/Conf/config.php';
				$data = I('post.');
				$data = "<?php\r\n return ".var_export($data,ture).";\r\n?>";
				if(file_put_contents($path, $data)){
					$this->success('更新高级设置完成','index');
				}else{
					$this->success('更新失败！');
				}
			}
		}
?>