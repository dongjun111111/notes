-- phpMyAdmin SQL Dump
-- version 2.7.0-pl1
-- http://www.phpmyadmin.net
-- 
-- 主机: localhost
-- 生成日期: 2015 年 07 月 12 日 15:50
-- 服务器版本: 5.5.27
-- PHP 版本: 5.3.23
-- 
--
-- 

-- --------------------------------------------------------

-- 
-- 表的结构 `web_album`
-- 

CREATE TABLE `web_album` (
  `al_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '相册逻辑ID',
  `al_name` varchar(64) NOT NULL COMMENT '相册名字',
  `al_url` varchar(128) NOT NULL COMMENT '相册封面',
  `al_hit` int(11) NOT NULL DEFAULT '1' COMMENT '相册点击',
  `al_view` int(11) NOT NULL DEFAULT '1' COMMENT '相册视图',
  `al_star` int(11) NOT NULL DEFAULT '1' COMMENT '相册星级',
  `al_time` int(10) NOT NULL COMMENT '相册添加时间',
  PRIMARY KEY (`al_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='相册表' AUTO_INCREMENT=12 ;

-- 
-- 导出表中的数据 `web_album`
-- 

INSERT INTO `web_album` VALUES (9, '测试相册9', '/Upload/Album/1430238303.png', 1, 1, 5, 1430238303);
INSERT INTO `web_album` VALUES (10, '大学', '/Upload/Album/1436573854.jpg', 1, 1, 5, 1436573854);
INSERT INTO `web_album` VALUES (11, '测试相册', '/Upload/Album/1436702267.jpg', 1, 1, 5, 1436702267);

-- --------------------------------------------------------

-- 
-- 表的结构 `web_album_content`
-- 

CREATE TABLE `web_album_content` (
  `al_id` int(11) NOT NULL DEFAULT '1' COMMENT '相册Id',
  `al_c_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '相册评论逻辑Id',
  `al_c_time` int(10) NOT NULL COMMENT '相册评论时间',
  `al_c_ip` varchar(16) NOT NULL COMMENT '相册评论ip',
  `al_c_content` text NOT NULL COMMENT '相册评论内容',
  `al_c_name` varchar(32) NOT NULL COMMENT '相册评论作者',
  `al_c_img` int(11) NOT NULL COMMENT '留言评论头像',
  `al_c_from` varchar(16) NOT NULL COMMENT '相册评论发表端',
  `al_c_email` varchar(32) NOT NULL COMMENT '相册评论邮箱',
  `al_c_url` varchar(32) NOT NULL COMMENT '相册评论域名',
  `al_c_uname` varchar(32) NOT NULL COMMENT '相册回复作者',
  `al_c_ucontent` text NOT NULL COMMENT '相册回复内容',
  `al_c_utime` int(10) DEFAULT NULL COMMENT '相册回复时间',
  PRIMARY KEY (`al_c_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='相册评论表' AUTO_INCREMENT=5 ;

-- 
-- 导出表中的数据 `web_album_content`
-- 

INSERT INTO `web_album_content` VALUES (10, 4, 1436715338, '42.81.44.134', '测试', '相册评论测试', 35, 'Win 8.1', '867012817@qq.com', '', '', '', NULL);

-- --------------------------------------------------------

-- 
-- 表的结构 `web_article`
-- 

CREATE TABLE `web_article` (
  `a_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '文章逻辑ID',
  `a_url` varchar(64) DEFAULT '' COMMENT '文章图片',
  `a_title` varchar(128) NOT NULL COMMENT '文章标题',
  `a_remark` varchar(256) DEFAULT '' COMMENT '文章描述',
  `a_keyword` varchar(32) DEFAULT '' COMMENT '文章关键字',
  `pid` int(11) NOT NULL DEFAULT '1' COMMENT '文章类别',
  `a_time` int(10) NOT NULL COMMENT '文章发表时间',
  `a_content` text NOT NULL COMMENT '文章内容',
  `a_view` int(11) NOT NULL DEFAULT '1' COMMENT '文章是否置顶',
  `a_hit` int(11) NOT NULL DEFAULT '1' COMMENT '文章点击量',
  `a_from` varchar(16) NOT NULL DEFAULT '1',
  `a_writer` varchar(64) NOT NULL COMMENT '作者',
  `a_ip` varchar(16) NOT NULL,
  PRIMARY KEY (`a_id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COMMENT='文章表' AUTO_INCREMENT=22 ;

-- 
-- 导出表中的数据 `web_article`
-- 

INSERT INTO `web_article` VALUES (19, '', 'PHP小技巧之&amp;&amp;', 'PHP小技巧之&amp;&amp;的用法', '&amp;&amp;', 1, 1436633365, '<p>PHP中一些小技巧</p><p>下面先看一段代码</p><pre class="brush:php;toolbar:false">&lt;?php\r\n&nbsp;&nbsp;&nbsp;&nbsp;...\r\n&nbsp;&nbsp;&nbsp;&nbsp;header(&quot;Content-type:text/javascript&quot;);\r\n&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;&quot;typeof{$this-&gt;callback}&nbsp;==&nbsp;&#39;function&#39;&nbsp;&amp;&amp;&nbsp;{$this-&gt;callback}(&quot;\r\n&nbsp;&nbsp;&nbsp;&nbsp;...\r\n?&gt;</pre><p>其中用到 JS 的 typeof 还有 PHP 中 &amp;&amp; 的用法，解释下上面代码的作用，第一步声明编码，第二步判断$this-&gt;callback的类型。如果是 function 那个 就显示 function {$this-&gt;callback}(.</p><p>百度了下 JS 的 typeof&nbsp;</p><pre class="brush:as3;toolbar:false">typeof&nbsp;可以用来检测给定变量的数据类型，可能的返回值：\r\n1.&nbsp;&#39;undefined&#39;&nbsp;---&nbsp;这个值未定义；\r\n2.&nbsp;&#39;boolean&#39;&nbsp;&nbsp;&nbsp;&nbsp;---&nbsp;这个值是布尔值；\r\n3.&nbsp;&#39;string&#39;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;---&nbsp;这个值是字符串；\r\n4.&nbsp;&#39;number&#39;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;---&nbsp;这个值是数值；\r\n5.&nbsp;&#39;object&#39;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;---&nbsp;这个值是对象或null；\r\n6.&nbsp;&#39;function&#39;&nbsp;&nbsp;&nbsp;&nbsp;---&nbsp;这个值是函数。</pre><p>说个例子来</p><pre class="brush:js;toolbar:false">&lt;script&gt;\r\nfunction&nbsp;test(){}\r\ntypeof&nbsp;(test())；\r\n&lt;/script&gt;</pre><p>返回的值是 funciton ，而上面时候的&nbsp;<span style="background-color: inherit; line-height: 1.5;">typeof 判断后面参数的属性如果为 function 那个执行下一步。为嘛会执行下一步呢？</span></p><p><span style="background-color: inherit; line-height: 1.5;">百度了下 PHP 的 &amp;&amp;</span></p><pre class="brush:as3;toolbar:false">&nbsp;如果前面的判断为假后面的则不执行，如果是真，继续执行下面的操作。</pre><p>巧用 PHP 自带的函数可以很好的优化程序代码，后续本博客的代码会进行优化。现在版本先实现功能。</p><p><br/></p>', 2, 16, 'Win 8.1', '隆航', '101.36.76.98');
INSERT INTO `web_article` VALUES (15, '', 'php中const与define的使用区别', 'php中const与define的使用区别', 'const', 1, 1436515036, '<p>&nbsp;1、const用于类成员变量定义，一旦定义不能改变值。define定义全局常量，在任何地方都可以访问。</p><p><br style="background-color: inherit;"/></p><p>2、define不能在类中定义而const可以。</p><p>&nbsp;</p><p>3、const不能在条件语句中定义常量</p><pre class="brush:php;toolbar:false">if&nbsp;(...)&nbsp;{\r\n&nbsp;&nbsp;&nbsp;&nbsp;const&nbsp;FOO&nbsp;=&nbsp;&#39;hello&#39;;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;无效\r\n}\r\n&nbsp;\r\nbut\r\n&nbsp;\r\nif&nbsp;(...)&nbsp;{\r\n&nbsp;&nbsp;&nbsp;&nbsp;define(&#39;FOO&#39;,&nbsp;&#39;hello&#39;);&nbsp;//&nbsp;有效\r\n}</pre><p><br style="background-color: inherit;"/></p><p>4、const采用一个普通的常量名称，define可以采用表达式作为名称。</p><p><br style="background-color: inherit;"/></p><pre class="brush:php;toolbar:false">const&nbsp;&nbsp;FOO&nbsp;=&nbsp;&#39;hello&#39;;\r\n&nbsp;\r\nfor&nbsp;($i&nbsp;=&nbsp;0;&nbsp;$i&nbsp;&lt;&nbsp;32;&nbsp;++$i)&nbsp;{\r\n&nbsp;&nbsp;&nbsp;&nbsp;define(&#39;hello&#39;&nbsp;.&nbsp;$i,&nbsp;1&nbsp;&lt;&lt;&nbsp;$i);\r\n}</pre><p><br style="background-color: inherit;"/></p><p>5、const只能接受静态的标量，而define可以采用任何表达式。</p><pre class="brush:php;toolbar:false">const&nbsp;hello=&nbsp;1&nbsp;&lt;&lt;&nbsp;5;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;无效</pre><p>&nbsp;</p><p>但是</p><pre class="brush:php;toolbar:false">define(&#39;hello&#39;,&nbsp;1&nbsp;&lt;&lt;&nbsp;5);&nbsp;//&nbsp;有效</pre><p><br style="background-color: inherit;"/></p><p>6、const 总是大小写敏感，然而define()可以通过第三个参数来定义大小写不敏感的常量</p><p></p><pre class="brush:php;toolbar:false">define(&#39;hello&#39;,&nbsp;&#39;hello&#39;,&nbsp;true);&nbsp;&nbsp;\r\necho&nbsp;hello;&nbsp;//&nbsp;hello</pre><p><br/></p><p>总结：</p><p>使用const简单易读，它本身是一个语言结构，而define是一个方法，用const定义在编译时比define快很多。</p><p><br/></p>', 1, 28, 'Win 7', '隆航', '59.172.57.206');
INSERT INTO `web_article` VALUES (21, '', '人生在于总结-大二', ' 转瞬我的大二就过去了，去年这个时候我还在这个时候写大一总结，时间总是在不知不觉中悄然的消逝。这一年我收获挺多的，也感触蛮多。', '大学', 2, 1405519200, '<p style="line-height: 1.75em;">转瞬我的大二就过去了，去年这个时候我还在这个时候写大一总结，时间总是在不知不觉中悄然的消逝。这一年我收获挺多的，也感触蛮多。<br/></p><p style="line-height: 1.75em;">2013/9\r\n月开始，我们学习新的课程HTML/ACCESS/SQL/PHP，新的课程我比较喜欢，然后学的也还行。现在让自己单独写个网站出来，基本功能还是可以\r\n的。不过后续的Java/Jsp/JQ/AXJX等网站特效却不是很熟悉。学习PHP的时候，尝试的去写自己喜欢的代码，也在不停的学习着PHP的其它知\r\n识。生命在于学习，需要学习的东西还有很多。寝室有个哥们去培训Java，有空的话我觉得自己也需要去学习下，学习的也不仅限于自己喜欢的，数据结构/数\r\n据库设计这些都需要恶补。</p><p style="line-height: 1.75em;">寝\r\n室其他人也有各自的前程，还有大三的几个月，我的大学就真正的说拜拜了。对大学生活花费最多的地方就是寝室了，每天晚上无聊的时候大家一起扯淡，聊到凌晨\r\n也不亦乐乎。看到现在寝室空空的感觉，心里也挺压抑的。不过离别是为了下次的重逢，在2014/9月的时候我们还会再聚。希望在最后离校的时候我不是最后\r\n一个，当然之前再来个不醉不归就完美了。<br/><a href="http://user.qzone.qq.com/1137212801/" target="_blank">@握不住的沙╮不如扬了它 </a>&nbsp; <a href="http://user.qzone.qq.com/478426078/" target="_blank">@把老子急死了</a>&nbsp; <a href="http://user.qzone.qq.com/651596900/" target="_blank">@651596900</a>&nbsp; <a href="http://user.qzone.qq.com/243823965/" target="_blank">@落葉歸根</a>&nbsp; <a href="http://user.qzone.qq.com/1103555280/" target="_blank">@天使不曾离开</a>&nbsp;</p><p style="line-height: 1.75em;">2014/12\r\n月，对我的大学来说是个值得纪念的月份，这个月发生了很多很多的事，对我的影响也是很重要的。在这里我碰到了提莫，让我的大学变得很完美的，在大学谈个恋\r\n爱很平常，不过对我来说就不是了。现在是我们在一起的200天的日子，我们在一起去过很多地方，一路上的照片也记录着我们到过地方。<br/><a href="http://user.qzone.qq.com/752136964/" target="_blank">@只为他，笑面如花</a>&nbsp;&nbsp;</p><p style="line-height: 1.75em;">在\r\n2014的上半年里，我看的更多的是以前没看清的事，没有绝对的正确和错误，如果总坚持自己是正确的，那么你就是错误的。抱着怀疑的态度看待自己的观点不\r\n一定是坏事，有些时候/有些事情换位思考完全不是那么回事。现在是我20岁的眼光看世界，也许等我30岁40岁的时候，再来看也许又是一种看法吧。</p><p style="line-height: 1.75em;">总结的话是我觉得我在学生会学到的最有用的东西，不断的给你自己计划和总结，你就会发觉生活是那么的充实很愉快。</p><p style="line-height: 1.75em;">大二，是大学的中继站，不妥协不放弃。<br/></p><p style="line-height: 1.75em;">对于目标，我想在学校里的时间不多了，现在需要的就是处理好关系，然后不断的自我学习。以后我会走上编程的路，虽然我也知道编程的路很长，很难。不过趁现在青春，趁现在年少。才能为梦想奋斗。我相信，我的朋友，我的哥们，我的家人会支持我的！</p><p style="line-height: 1.75em;">对于恋爱，现在我也可以很自豪的说，咱脱离单身一族了，身边一起长大的几个朋友也都脱离了单身的队伍，一边呢替他们高兴，一边也告诉自己要好好去经营自己的爱情，现在未知的太多，好好充实自己，将来才能有资本说话。</p><p style="line-height: 1.75em;">对于学习，我想说的是一入It深似海，在It世界里不断的出现新的事物，如果你不学习，那么你终将是时代的淘汰物。只有不断的去学习心得事物，才能在It这一行走下去。代码是一门学问，学的越深就越发觉自己要不会的更多，如此循环，学习就变得很重要很重要了。</p><p style="line-height: 1.75em;">对\r\n于学生会，在学生会学习部担任部长期间，自己做的不是很称职，不过我更多地想法是让他们自己去做事情，而我只是去指导他们。我一味的去监督他们去做事情，\r\n一来对他们自己不好，二来我不喜欢约束别人。这份责任本来没有别人去要求你做，既然承担了，就应该好好的坚持下去。如果需要人来监督，那么这份责任就变了\r\n味道。至少他们这届没让我失望吧。也希望下届的学习部可以做好吧。<br/><a href="http://user.qzone.qq.com/774694235/" target="_blank">@浅听风语</a>&nbsp; <a href="http://user.qzone.qq.com/2435607249/" target="_blank">@Never &nbsp;say &nbsp;die</a>&nbsp; <a href="http://user.qzone.qq.com/1139836810/" target="_blank">@苦是咖啡留下的美</a>&nbsp; <a href="http://user.qzone.qq.com/1505375292/" target="_blank">@柰萙</a>&nbsp; <a href="http://user.qzone.qq.com/2569876692/" target="_blank">@不后悔</a>&nbsp;<br/>&nbsp;</p><p style="line-height: 1.75em;">好吧，我的大学，快了接近尾声，编程的路也才刚开始……</p><p><br/></p>', 2, 7, 'Win 8.1', '隆航', '101.36.76.98');
INSERT INTO `web_article` VALUES (16, '', 'Mysql联合查询', 'MySQL联合查询效率较高 ，本文简单的说下几个例子。', 'Mysql', 1, 1436544545, '<p><span style="background-color: inherit; line-height: 1.5;">MySQL联合查询效率较高，以下例子来说明联合查询（内联、左联、右联、全联）的好处：&nbsp;</span></p><p><br style="background-color: inherit;"/></p><p>T1表结构（用户名,密码） <br/></p><table align="center"><tbody><tr class="firstRow"><td style="border: 1px solid rgb(127, 127, 127); word-break: break-all;" align="center" valign="middle">userid</td><td style="border: 1px solid rgb(127, 127, 127); word-break: break-all;" align="center" valign="middle">username</td><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">password</td></tr><tr><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">1</td><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">jack</td><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">pwd1</td></tr><tr><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">2</td><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">owen</td><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">pwd2</td></tr></tbody></table><p><br/></p><p>T2表结构（用户名,密码）&nbsp; <br/></p><table align="center"><tbody><tr class="firstRow"><td style="border: 1px solid rgb(127, 127, 127); word-break: break-all;" align="center" valign="middle">userid</td><td style="border: 1px solid rgb(127, 127, 127); word-break: break-all;" align="center" valign="middle">jifen</td><td style="border: 1px solid rgb(127, 127, 127); word-break: break-all;" align="center" valign="middle">dengji<br/></td></tr><tr><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">1<br/></td><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">20<br/></td><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">3<br/></td></tr><tr><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">3<br/></td><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">50<br/></td><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">6<br/></td></tr></tbody></table><p><br/></p><p>第一：内联（inner join）</p><p>如果想把用户信息、积分、等级都列出来，那么一般会这样写：</p><pre class="brush:sql;toolbar:false">select&nbsp;*&nbsp;from&nbsp;T1,&nbsp;T3&nbsp;where&nbsp;T1.userid&nbsp;=&nbsp;T3.userid</pre><p>（其实这样的结果等同于select * from T1 inner join T3 on T1.userid=T3.userid ）。</p><p><br style="background-color: inherit;"/></p><p>把两个表中都存在userid的行拼成一行（即内联），但后者的效率会比前者高很多，建议用后者（内联）的写法。</p><p><br style="background-color: inherit;"/></p><p>SQL语句：</p><pre class="brush:sql;toolbar:false">select&nbsp;*&nbsp;from&nbsp;T1&nbsp;inner&nbsp;join&nbsp;T2&nbsp;on&nbsp;T1.userid&nbsp;=&nbsp;T2.userid</pre><p><br style="background-color: inherit;"/></p><p>运行结果&nbsp; <br/></p><table align="center"><tbody><tr class="firstRow"><td style="border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">T1.userid</td><td style="border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">username</td><td style="border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">password</td><td style="border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">T2.userid</td><td style="border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">jifen</td><td style="border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">dengji&nbsp; <br/></td></tr><tr><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">1<br/></td><td style="border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">jack</td><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">pwd1</td><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">1<br/></td><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">20<br/></td><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">3<br/></td></tr></tbody></table><p><br/></p><p>第二：左联（left outer join）</p><p>显示左表T1中的所有行，并把右表T2中符合条件加到左表T1中；</p><p>右表T2中不符合条件，就不用加入结果表中，并且NULL表示。</p><p><br style="background-color: inherit;"/></p><p>SQL语句：</p><pre class="brush:sql;toolbar:false">select&nbsp;*&nbsp;from&nbsp;T1&nbsp;left&nbsp;outer&nbsp;join&nbsp;T2&nbsp;on&nbsp;T1.userid&nbsp;=&nbsp;T2.userid</pre><p><br/></p><p>运行结果&nbsp; <br/></p><table align="center" height="100"><tbody><tr class="firstRow"><td style="border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">T1.userid</td><td style="border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">username</td><td style="border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">password</td><td style="border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">T2.userid</td><td style="border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">jifen</td><td style="border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">dengji</td></tr><tr><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">1<br/></td><td style="border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">jack</td><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">pwd1</td><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">1<br/></td><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">20<br/></td><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">3<br/></td></tr><tr><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">2<br/></td><td style="border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">owen</td><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">pwd2</td><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">NULL</td><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">NULL</td><td style="word-break: break-all; border: 1px solid rgb(127, 127, 127);" align="center" valign="middle">NULL</td></tr></tbody></table><p><br/></p><p>第三：右联（right outer join）。</p><p>显示右表T2中的所有行，并把左表T1中符合条件加到右表T2中；</p><p>左表T1中不符合条件，就不用加入结果表中，并且NULL表示。</p><p><br style="background-color: inherit;"/></p><p>SQL语句：</p><pre class="brush:sql;toolbar:false">select&nbsp;*&nbsp;from&nbsp;T1&nbsp;right&nbsp;outer&nbsp;join&nbsp;T2&nbsp;on&nbsp;T1.userid&nbsp;=&nbsp;T2.userid</pre><p><br style="background-color: inherit;"/></p><p>运行结果&nbsp; <br/></p><table align="center"><tbody><tr class="firstRow"><td style="border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">T1.userid</td><td style="border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">username</td><td style="border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">password</td><td style="border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">T2.userid</td><td style="border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">jifen</td><td style="border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">dengji</td></tr><tr><td style="word-break: break-all; border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">1<br/></td><td style="border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">jack</td><td style="word-break: break-all; border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">pwd1</td><td style="word-break: break-all; border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">1<br/></td><td style="word-break: break-all; border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">20<br/></td><td style="word-break: break-all; border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">3<br/></td></tr><tr><td style="border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">NULL</td><td style="border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">&nbsp; NULL</td><td style="border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">NULL</td><td style="word-break: break-all; border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">3<br/></td><td style="word-break: break-all; border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">50<br/></td><td style="word-break: break-all; border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">6<br/></td></tr></tbody></table><p><br/></p><p>第四：全联（full outer join）</p><p>显示左表T1、右表T2两边中的所有行，即把左联结果表 + 右联结果表组合在一起，然后过滤掉重复的。</p><p><br style="background-color: inherit;"/></p><p>SQL语句：</p><pre class="brush:sql;toolbar:false">select&nbsp;*&nbsp;from&nbsp;T1&nbsp;full&nbsp;outer&nbsp;join&nbsp;T2&nbsp;on&nbsp;T1.userid&nbsp;=&nbsp;T2.userid</pre><p>&nbsp;</p><p>运行结果&nbsp; <br/></p><table align="center"><tbody><tr class="firstRow"><td style="border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">T1.userid</td><td style="border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">username</td><td style="border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">password</td><td style="border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">T2.userid</td><td style="border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">jifen</td><td style="border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">dengji</td></tr><tr><td style="word-break: break-all; border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">1<br/></td><td style="border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">jack&nbsp; <br/></td><td style="word-break: break-all; border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">pwd1</td><td style="word-break: break-all; border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">1<br/></td><td style="word-break: break-all; border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">20<br/></td><td style="word-break: break-all; border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">3<br/></td></tr><tr><td style="word-break: break-all; border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">2<br/></td><td style="border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">owen</td><td style="word-break: break-all; border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">pwd2</td><td style="border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">NULL</td><td style="border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">NULL</td><td style="border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">NULL</td></tr><tr><td style="word-break: break-all; border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">NULL</td><td style="word-break: break-all; border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">NULL</td><td style="word-break: break-all; border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">NULL</td><td style="word-break: break-all; border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">3<br/></td><td style="word-break: break-all; border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">50<br/></td><td style="word-break: break-all; border: 1px solid rgb(221, 221, 221);" align="center" valign="middle">6<br/></td></tr></tbody></table><p><br/></p><p>总结，关于联合查询，效率的确比较高，4种联合方式如果可以灵活使用，基本上复杂的语句结构也会简单起来。 <br/></p><p><br/></p>', 1, 40, 'Win 8.1', '隆航', '114.111.167.16');
INSERT INTO `web_article` VALUES (9, '', ' ThinkPHP中Volist标签的用法', 'volist标签通常用于查询数据集（select方法）的结果输出，通常模型的select方法返回的结果是一个二维数组，可以直接使用volist标签进行输出。 在控制器中首先对模版赋值：', ' Volis', 3, 1433549166, '<p>volist标签通常用于查询数据集（select方法）的结果输出，通常模型的select方法返回的结果是一个二维数组，可以直接使用volist标签进行输出。\r\n在控制器中首先对模版赋值：</p><pre style="" class="prettyprint linenums prettyprinted">$User&nbsp;=&nbsp;M(&#39;User&#39;);$list&nbsp;=&nbsp;$User-&gt;limit(10)-&gt;select();$this-&gt;assign(&#39;list&#39;,$list);</pre><p>在模版定义如下，循环输出用户的编号和姓名：</p><pre style="" class="prettyprint linenums prettyprinted">&lt;volist&nbsp;name=&quot;list&quot;&nbsp;id=&quot;vo&quot;&gt;{$vo.id}:{$vo.name}&lt;br/&gt;&lt;/volist&gt;</pre><p>Volist标签的name属性表示模板赋值的变量名称，因此不可随意在模板文件中改变。id表示当前的循环变量，可以随意指定，但确保不要和name属性冲突，例如：</p><pre style="" class="prettyprint linenums prettyprinted">&lt;volist&nbsp;name=&quot;list&quot;&nbsp;id=&quot;data&quot;&gt;{$data.id}:{$data.name}&lt;br/&gt;&lt;/volist&gt;</pre><p>支持输出查询结果中的部分数据，例如输出其中的第5～15条记录</p><pre style="" class="prettyprint linenums prettyprinted">&lt;volist&nbsp;name=&quot;list&quot;&nbsp;id=&quot;vo&quot;&nbsp;offset=&quot;5&quot;&nbsp;length=&#39;10&#39;&gt;{$vo.name}&lt;/volist&gt;</pre><p>输出偶数记录</p><pre style="" class="prettyprint linenums prettyprinted">&lt;volist&nbsp;name=&quot;list&quot;&nbsp;id=&quot;vo&quot;&nbsp;mod=&quot;2&quot;&nbsp;&gt;&lt;eq&nbsp;name=&quot;mod&quot;&nbsp;value=&quot;1&quot;&gt;{$vo.name}&lt;/eq&gt;&lt;/volist&gt;</pre><p>Mod属性还用于控制一定记录的换行，例如：</p><pre style="" class="prettyprint linenums prettyprinted">&lt;volist&nbsp;name=&quot;list&quot;&nbsp;id=&quot;vo&quot;&nbsp;mod=&quot;5&quot;&nbsp;&gt;{$vo.name}&lt;eq&nbsp;name=&quot;mod&quot;&nbsp;value=&quot;4&quot;&gt;&lt;br/&gt;&lt;/eq&gt;&lt;/volist&gt;</pre><p>为空的时候输出提示：</p><pre style="" class="prettyprint linenums prettyprinted">&lt;volist&nbsp;name=&quot;list&quot;&nbsp;id=&quot;vo&quot;&nbsp;empty=&quot;暂时没有数据&quot;&nbsp;&gt;{$vo.id}|{$vo.name}&lt;/volist&gt;</pre><p>empty属性不支持直接传入html语法，但可以支持变量输出，例如：</p><pre style="" class="prettyprint linenums prettyprinted">$this-&gt;assign(&#39;empty&#39;,&#39;&lt;span&nbsp;class=&quot;empty&quot;&gt;没有数据&lt;/span&gt;&#39;);$this-&gt;assign(&#39;list&#39;,$list);</pre><p>然后在模板中使用：</p><pre style="" class="prettyprint linenums prettyprinted">&lt;volist&nbsp;name=&quot;list&quot;&nbsp;id=&quot;vo&quot;&nbsp;empty=&quot;$empty&quot;&nbsp;&gt;{$vo.id}|{$vo.name}&lt;/volist&gt;</pre><p>输出循环变量</p><pre style="" class="prettyprint linenums prettyprinted">&lt;volist&nbsp;name=&quot;list&quot;&nbsp;id=&quot;vo&quot;&nbsp;key=&quot;k&quot;&nbsp;&gt;{$k}.{$vo.name}&lt;/volist&gt;</pre><p>如果没有指定key属性的话，默认使用循环变量i，例如：</p><pre style="" class="prettyprint linenums prettyprinted">&lt;volist&nbsp;name=&quot;list&quot;&nbsp;id=&quot;vo&quot;&nbsp;&nbsp;&gt;{$i}.{$vo.name}&lt;/volist&gt;</pre><p>如果要输出数组的索引，可以直接使用key变量，和循环变量不同的是，这个key是由数据本身决定，而不是循环控制的，例如：</p><pre style="" class="prettyprint linenums prettyprinted">&lt;volist&nbsp;name=&quot;list&quot;&nbsp;id=&quot;vo&quot;&nbsp;&nbsp;&gt;{$key}.{$vo.name}&lt;/volist&gt;复制代码</pre><p>模板中可以直接使用函数设定数据集，而不需要在控制器中给模板变量赋值传入数据集变量，如：</p><pre style="" class="prettyprint linenums prettyprinted">&lt;volist&nbsp;name=&quot;:fun(&#39;arg&#39;)&quot;&nbsp;id=&quot;vo&quot;&gt;{$vo.name}&lt;/volist&gt;</pre><p><br/></p>', 2, 50, 'Win 8.1', '隆航', '101.36.76.98');
INSERT INTO `web_article` VALUES (17, '', 'PHP微信红包和抽奖代码', 'PHP微信红包和抽奖代码', 'PHP', 1, 1436580871, '<p></p><p>前段时间面试的一家公司的问题是PHP微信红包和抽奖代码的，当时恶补了一下代码的。下面是我自己整理出来的两份代码：<br/></p><p>微信红包类的写法：<br/>具体思路是，定义一个总钱数和一个人数，然后最小值为默认0.01元，然后进行循环，设置安全值是为了让后面的人都能拿到钱。具体的写法就不写了，自己看吧&nbsp;</p><pre class="brush:php;toolbar:false">&lt;?php\r\n&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;微信红包算法\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;header(&quot;content-type:text/html;charset=utf-8&quot;);\r\n&nbsp;&nbsp;&nbsp;&nbsp;$sum&nbsp;=&nbsp;10;&nbsp;&nbsp;//总价钱\r\n&nbsp;&nbsp;&nbsp;&nbsp;$num&nbsp;=&nbsp;8&nbsp;;&nbsp;&nbsp;//人数\r\n&nbsp;&nbsp;&nbsp;&nbsp;$min&nbsp;=&nbsp;0.01;&nbsp;&nbsp;&nbsp;&nbsp;//最少值\r\n&nbsp;&nbsp;&nbsp;&nbsp;for($i=1;$i&lt;$num;$i++){\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$row&nbsp;=&nbsp;($sum-($num-$i)*$min)/($num-$i);//&nbsp;安全值\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$money&nbsp;=&nbsp;mt_rand($min*100,$row*100)/100;\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$sum&nbsp;-=&nbsp;$money;\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;&#39;第&#39;.$i.&#39;人，领取&#39;.$money.&#39;元，剩下&#39;.$sum.&#39;元&lt;br/&gt;&#39;;\r\n&nbsp;&nbsp;&nbsp;&nbsp;}\r\n&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;&#39;第&#39;.$num.&#39;人，领取&#39;.$sum.&#39;元，剩下&#39;.$sum.&#39;元&#39;;\r\n?&gt;</pre><p>&nbsp;抽奖代码</p><pre class="brush:php;toolbar:false">&lt;?php\r\n&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;抽奖\r\n&nbsp;header(&quot;content-type:text/html;charset=utf-8&quot;);\r\n&nbsp;&nbsp;&nbsp;&nbsp;function&nbsp;get_rand($arr){\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$arr_sum&nbsp;=&nbsp;array_sum($arr);\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$arr_rand&nbsp;=&nbsp;mt_rand(1,$arr_sum);\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;foreach($arr&nbsp;as&nbsp;$key&nbsp;=&gt;&nbsp;$arr_num){\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$arr_sum&nbsp;-=&nbsp;$arr_num;\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if($arr_rand&gt;$arr_sum){\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;$key;\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}\r\n&nbsp;&nbsp;&nbsp;&nbsp;}\r\n&nbsp;&nbsp;&nbsp;&nbsp;$p&nbsp;=&nbsp;array(\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;0&#39;&nbsp;=&gt;&nbsp;array(&#39;id&#39;=&gt;1,&#39;info&#39;=&gt;&#39;一等奖&#39;,&#39;v&#39;=&gt;1),\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;1&#39;&nbsp;=&gt;&nbsp;array(&#39;id&#39;=&gt;2,&#39;info&#39;=&gt;&#39;二等奖&#39;,&#39;v&#39;=&gt;5),\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;2&#39;&nbsp;=&gt;&nbsp;array(&#39;id&#39;=&gt;3,&#39;info&#39;=&gt;&#39;三等奖&#39;,&#39;v&#39;=&gt;10),\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;3&#39;&nbsp;=&gt;&nbsp;array(&#39;id&#39;=&gt;4,&#39;info&#39;=&gt;&#39;四等奖&#39;,&#39;v&#39;=&gt;34)\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;);\r\n&nbsp;&nbsp;&nbsp;&nbsp;foreach($p&nbsp;as&nbsp;$key&nbsp;=&gt;&nbsp;$value){\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$arr[$value[&#39;id&#39;]]&nbsp;=&nbsp;$value[&#39;v&#39;];\r\n&nbsp;&nbsp;&nbsp;&nbsp;}\r\n&nbsp;&nbsp;&nbsp;&nbsp;$rid&nbsp;=&nbsp;get_rand($arr);\r\n&nbsp;&nbsp;&nbsp;&nbsp;$res[&#39;yes&#39;]&nbsp;=&nbsp;$p[$rid-1][&#39;info&#39;];\r\n&nbsp;&nbsp;&nbsp;&nbsp;unset&nbsp;($p[$rid-1])&nbsp;;\r\n&nbsp;&nbsp;&nbsp;&nbsp;shuffle&nbsp;($p);\r\n&nbsp;&nbsp;&nbsp;&nbsp;for($i=0;$i&lt;count($p);$i++){\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$pr[]=&nbsp;$p[$i][&#39;info&#39;];\r\n&nbsp;&nbsp;&nbsp;&nbsp;}\r\n&nbsp;&nbsp;&nbsp;&nbsp;$res[&#39;no&#39;]&nbsp;=&nbsp;$pr;\r\n&nbsp;&nbsp;&nbsp;&nbsp;var_dump($res);\r\n?&gt;</pre><p><br/></p><p>有需要请自行研究哈。</p>&nbsp; &nbsp;<p></p><p><br/></p><br/>', 2, 22, 'Win 7', '隆航', '59.172.56.23');
INSERT INTO `web_article` VALUES (18, '', 'Hello World!', '程序一行，万事皆起于Hello World!', 'Hello', 4, 1436621121, '<p style="line-height: 1.75em;">程序一行，万事皆起于Hello World!</p><p style="line-height: 1.75em;">欢迎访问我的博客！</p><p style="line-height: 1.75em;">在这里，有我个人的学习笔记，有我的程序分享，还有一些杂七杂八的东西在这里堆积。</p><p style="line-height: 1.75em;">2012年开始我接触代码，2013年开始接触网页设计，学习过ps,fl,access,c,java,mysql,php,sql,html等等。至今快2年了仍然是一个不折不扣菜鸟，个人一直喜欢网络上的新鲜事物和对即视的代码有着特殊的好感。</p><p style="line-height: 1.75em;">活了20纪念，感叹最多的还是人活着就是为了生存，而生存易生活难，每每很多问题困扰我的时候，我总是想着自己的网名：我是兴高采烈，然后让自己开开心心的过每一天，把不开心的事都一一过滤。每一天都有计划和学习，那样的日子才是最好的，不是么？</p><p style="line-height: 1.75em;">2013年底认识她，原为她喜欢LOL的一个角色提莫，大家给她起的外号为&#39;提莫队长&#39;，然后我在开始筹备这个博客。从开始到现在几个经历版本才发现只有属于自己的程序才是完全适合自己的。2015年初开始自己集合框架开始写网站的代码。2015年6月底开始第一个版本的测试，之后每隔一个月会把之前的网站打包，或者把更新的东西打包分享给交流群里的小伙伴，大家一起学习，一起进步。</p>', 2, 17, 'Win 8.1', '隆航', '101.36.76.98');
INSERT INTO `web_article` VALUES (20, '', 'ThinkPHP正则路由分享', '在ThinkPHP中为了更好的去适应SEO，路由肯定少不了。而规则路由的话在某些方面肯定不如正则路由。我分享下自己的路由规则。', 'ThinkPHP', 3, 1436671470, '<p style="line-height: 1.75em;"><span style="font-size: 14px;">在ThinkPHP中为了更好的去适应SEO，路由肯定少不了。而规则路由的话在某些方面肯定不如正则路由。我分享下自己的路由规则。</span></p><pre class="brush:php;toolbar:false"><p style="line-height: 1.75em;">&lt;?php<br/>...<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;URL_MODEL&#39;&nbsp;=&gt;2,&nbsp;&nbsp;&nbsp;&nbsp;//开启路由<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;URL_ROUTER_ON&#39;&nbsp;=&gt;&nbsp;true,&nbsp;&nbsp;&nbsp;&nbsp;//路由规则&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;URL_ROUTE_RULES&#39;&nbsp;=&gt;&nbsp;array(&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;/^index$/&#39;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&gt;&nbsp;&nbsp;&nbsp;&nbsp;&#39;Index/index&#39;,&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;/^about$/&#39;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&gt;&nbsp;&nbsp;&nbsp;&nbsp;&#39;About/index&#39;,&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;feel&nbsp;对应列表页&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;feel/page/2&nbsp;对应分页&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;feel-2&nbsp;对应详情&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;/^feel$/&#39;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&gt;&nbsp;&nbsp;&#39;Feel/index&#39;,&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;/^feel\\/page\\/(\\d{1,})$/&#39;&nbsp;&nbsp;=&gt;&nbsp;&nbsp;&#39;Feel/index?page=:1&#39;,&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;/^feel-(\\d{1,})$/&#39;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&gt;&nbsp;&nbsp;&#39;Feel/index?id=:1&#39;,&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;/^gustbook$/&#39;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&gt;&nbsp;&nbsp;&#39;Gustbook/index&#39;,&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;/^gustbook\\/(\\d{1,})$/&#39;&nbsp;&nbsp;&nbsp;&nbsp;=&gt;&nbsp;&nbsp;&nbsp;&nbsp;&#39;Gustbook/index?page=:1&#39;,&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;/^album-(\\d{1,5})$/&#39;&nbsp;&nbsp;&nbsp;=&gt;&nbsp;&nbsp;&#39;Album/look?id=:1&#39;,&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;/^album$/&#39;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&gt;&nbsp;&nbsp;&#39;Album/index&#39;,&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;/^class-(\\d{1,})\\/page\\/(\\d{1,})$/&#39;&nbsp;&nbsp;=&gt;&nbsp;&nbsp;&#39;Class/index?id=:1&amp;page=:2&#39;,&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;/^class-(\\d)$/&#39;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&gt;&nbsp;&nbsp;&#39;Class/index?id=:1&#39;,&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#39;/^article-(\\d{1,5})$/&#39;&nbsp;=&gt;&nbsp;&nbsp;&#39;Article/index?id=:1&#39;,<br/>...<br/>?&gt;<br/></p></pre><p style="line-height: 1.75em;">以上我的自己的路由规则，自己的博客，自己来定义规则。收获的不仅仅是小小的满足感，更多的是学习。</p><p style="line-height: 1.75em;">附上ThinkPHP的路由链接，和一个在线正则的工具。</p><p style="line-height: 1.75em;">THinkPHP 3.2手册： <a _src="http://document.thinkphp.cn/manual_3_2.html#route" href="http://document.thinkphp.cn/manual_3_2.html#route">http://document.thinkphp.cn/manual_3_2.html#route</a><br/></p><p style="line-height: 1.75em;">正则在线测试：<a _src="http://tool.chinaz.com/regex/" href="http://tool.chinaz.com/regex/">http://tool.chinaz.com/regex/</a><br/></p><p style="line-height: 1.75em;">如果有问题，或者我哪里写的不对，可以留言联系我。谢谢。<br/> &nbsp;</p>', 2, 14, 'Win 8.1', '隆航', '101.36.76.98');

-- --------------------------------------------------------

-- 
-- 表的结构 `web_article_content`
-- 

CREATE TABLE `web_article_content` (
  `a_id` int(11) NOT NULL DEFAULT '1' COMMENT '文章Id',
  `a_c_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '文章评论逻辑Id',
  `a_c_time` int(10) NOT NULL COMMENT '文章评论时间',
  `a_c_ip` varchar(16) NOT NULL COMMENT '文章评论ip',
  `a_c_content` text NOT NULL COMMENT '文章评论内容',
  `a_c_name` varchar(32) NOT NULL COMMENT '文章评论作者',
  `a_c_img` int(11) NOT NULL COMMENT '文章评论头像',
  `a_c_from` varchar(16) NOT NULL COMMENT '文章评论发表端',
  `a_c_email` varchar(32) NOT NULL COMMENT '文章评论邮箱',
  `a_c_url` varchar(32) NOT NULL COMMENT '文章评论域名',
  `a_c_uname` varchar(32) NOT NULL COMMENT '文章回复作者',
  `a_c_ucontent` text NOT NULL COMMENT '文章回复内容',
  `a_c_utime` int(10) DEFAULT NULL COMMENT '文章回复时间',
  PRIMARY KEY (`a_c_id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COMMENT='文章评论表' AUTO_INCREMENT=31 ;

-- 
-- 导出表中的数据 `web_article_content`
-- 

INSERT INTO `web_article_content` VALUES (20, 30, 1436702112, '101.36.76.98', '评论文章测试[em_13]', '评论文章测试', 98, 'Win 8.1', '867012817@qq.com', '', '', '', NULL);

-- --------------------------------------------------------

-- 
-- 表的结构 `web_gustbook`
-- 

CREATE TABLE `web_gustbook` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '留言Id',
  `c_time` int(10) NOT NULL COMMENT '留言评论时间',
  `c_ip` varchar(16) NOT NULL COMMENT '留言评论ip',
  `c_content` text NOT NULL COMMENT '留言评论内容',
  `c_name` varchar(32) NOT NULL COMMENT '留言评论作者',
  `c_img` int(11) NOT NULL,
  `c_from` varchar(16) NOT NULL COMMENT '留言评论发表端',
  `c_email` varchar(32) NOT NULL COMMENT '留言评论邮箱',
  `c_url` varchar(32) NOT NULL COMMENT '留言评论域名',
  `c_uname` varchar(32) NOT NULL COMMENT '留言回复作者',
  `c_ucontent` text NOT NULL COMMENT '留言回复内容',
  `c_utime` int(10) DEFAULT NULL COMMENT '留言回复时间',
  PRIMARY KEY (`c_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='文章评论表' AUTO_INCREMENT=11 ;

-- 
-- 导出表中的数据 `web_gustbook`
-- 

INSERT INTO `web_gustbook` VALUES (10, 1436702143, '101.36.76.98', '留言测试[em_19]', '留言测试', 93, 'Win 8.1', '867012817@qq.com', '', '', '', NULL);

-- --------------------------------------------------------

-- 
-- 表的结构 `web_link`
-- 

CREATE TABLE `web_link` (
  `l_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '友情连接id',
  `l_name` varchar(64) NOT NULL COMMENT '友情链接名称',
  `l_url` varchar(128) NOT NULL COMMENT '友情连接地址',
  `l_img` int(11) NOT NULL COMMENT '友情连接头像',
  `l_sort` int(11) NOT NULL COMMENT '友情连接排序',
  `l_remark` text NOT NULL COMMENT '友情链接介绍',
  `l_view` int(11) NOT NULL COMMENT '是否显示',
  `l_level` int(11) NOT NULL COMMENT '显示级别',
  `l_email` varchar(64) NOT NULL COMMENT '友链邮箱',
  `l_time` int(11) NOT NULL COMMENT '添加时间',
  `l_ip` varchar(16) NOT NULL COMMENT '友链IP地址',
  `l_uname` varchar(32) NOT NULL COMMENT '友链回复人',
  `l_ucontent` text NOT NULL COMMENT '友链回复内容',
  `l_utime` int(11) NOT NULL COMMENT '友链回复时间',
  PRIMARY KEY (`l_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='友情连接表' AUTO_INCREMENT=5 ;

-- 
-- 导出表中的数据 `web_link`
-- 

INSERT INTO `web_link` VALUES (1, '偏执大叔', 'conglee.com', 1, 1, '偏执大叔', 1, 1, '', 1430238360, '', '隆航', '', 1436667953);
INSERT INTO `web_link` VALUES (2, '浅听风雨', 'foryan.com', 0, 1, '浅听风雨的个人博客', 1, 1, '', 0, '', '隆航', '', 1436667934);
INSERT INTO `web_link` VALUES (3, 'Bootstrap', 'v3.bootcss.com', 0, 2, 'Bootstrap中文网站', 0, 1, '', 0, '', '隆航', '', 1436667796);
INSERT INTO `web_link` VALUES (4, 'ThinkPHP', 'thinkphp.cn', 0, 0, 'ThinkPHP官网', 0, 1, '', 0, '', '隆航', '', 1436667802);

-- --------------------------------------------------------

-- 
-- 表的结构 `web_picture`
-- 

CREATE TABLE `web_picture` (
  `p_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '图片逻辑id',
  `p_url` varchar(64) NOT NULL COMMENT '图片地址',
  `p_view` int(11) NOT NULL COMMENT '图片视图',
  `al_id` int(11) NOT NULL COMMENT '图片相册Id',
  PRIMARY KEY (`p_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COMMENT='图片表' AUTO_INCREMENT=21 ;

-- 
-- 导出表中的数据 `web_picture`
-- 

INSERT INTO `web_picture` VALUES (17, '/Upload/Album/album-9/1436573267.png', 1, 9);
INSERT INTO `web_picture` VALUES (18, '/Upload/Album/album-9/1436573719.jpg', 1, 9);
INSERT INTO `web_picture` VALUES (19, '/Upload/Album/album-10/1436573884.jpg', 1, 10);
INSERT INTO `web_picture` VALUES (20, '/Upload/Album/album-11/1436702303.jpg', 1, 11);

-- --------------------------------------------------------

-- 
-- 表的结构 `web_said`
-- 

CREATE TABLE `web_said` (
  `s_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '说说逻辑排序',
  `s_content` text NOT NULL COMMENT '说说内容',
  `s_from` varchar(16) NOT NULL DEFAULT '1',
  `s_writer` varchar(32) NOT NULL COMMENT '说说作者',
  `s_hit` int(11) NOT NULL DEFAULT '1' COMMENT '说说点击量',
  `s_view` int(11) NOT NULL DEFAULT '1' COMMENT '说说的显推',
  `s_ip` varchar(16) NOT NULL COMMENT '说说ip',
  `s_time` int(10) NOT NULL COMMENT '说说发表时间',
  PRIMARY KEY (`s_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='说说表' AUTO_INCREMENT=13 ;

-- 
-- 导出表中的数据 `web_said`
-- 

INSERT INTO `web_said` VALUES (4, '<p>test1</p>', '', 'admin', 1, 1, '42.81.44.141', 1436400897);
INSERT INTO `web_said` VALUES (6, '<p>test2</p>', '', 'admin', 3, 1, '42.81.44.141', 1436400905);
INSERT INTO `web_said` VALUES (5, '<p>test3</p>', '', 'admin', 1, 1, '42.81.44.141', 1436400912);
INSERT INTO `web_said` VALUES (7, '<p>test4</p>', '', 'admin', 2, 1, '42.81.44.141', 1436400919);
INSERT INTO `web_said` VALUES (8, '<p>test5</p>', '', 'admin', 13, 1, '42.81.44.141', 1436400928);
INSERT INTO `web_said` VALUES (9, '<p>test6</p>', '', 'admin', 9, 1, '42.81.44.141', 1436400936);
INSERT INTO `web_said` VALUES (12, '<p>相册评论尚未完成。待开发。</p>', 'Win 8.1', '隆航', 1, 1, '114.111.167.14', 1436574328);
INSERT INTO `web_said` VALUES (10, '<p>测试说说<img src="http://www.qqzhi.com/uploadpic/2014-09-26/105946673.jpg" alt="105946673.jpg"/></p>', 'Windows 8.1', 'admin', 12, 1, '116.211.131.16', 1430760327);
INSERT INTO `web_said` VALUES (11, '<p>心好累</p>', 'iPhone', '隆航', 1, 1, '122.228.228.106', 1434989459);

-- --------------------------------------------------------

-- 
-- 表的结构 `web_said_content`
-- 

CREATE TABLE `web_said_content` (
  `s_id` int(11) NOT NULL DEFAULT '1' COMMENT '说说Id',
  `s_c_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '说说评论逻辑Id',
  `s_c_time` int(10) NOT NULL COMMENT '说说评论时间',
  `s_c_ip` varchar(16) NOT NULL COMMENT '说说评论ip',
  `s_c_content` text NOT NULL COMMENT '说说评论内容',
  `s_c_name` varchar(32) NOT NULL COMMENT '说说评论作者',
  `s_c_img` int(11) NOT NULL COMMENT '说说评论头像',
  `s_c_from` varchar(16) NOT NULL COMMENT '说说评论发表端',
  `s_c_email` varchar(32) NOT NULL COMMENT '说说评论邮箱',
  `s_c_url` varchar(32) NOT NULL COMMENT '说说评论域名',
  `s_c_uname` varchar(32) NOT NULL COMMENT '说说回复作者',
  `s_c_ucontent` text NOT NULL COMMENT '说说回复内容',
  `s_c_utime` int(10) DEFAULT NULL COMMENT '说说回复时间',
  PRIMARY KEY (`s_c_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='说说评论表' AUTO_INCREMENT=4 ;

-- 
-- 导出表中的数据 `web_said_content`
-- 


-- --------------------------------------------------------

-- 
-- 表的结构 `web_system`
-- 

CREATE TABLE `web_system` (
  `id` int(11) NOT NULL COMMENT 'id',
  `title` varchar(128) NOT NULL COMMENT '网站标题',
  `title_2` varchar(256) NOT NULL COMMENT '网站二级标题',
  `keyword` varchar(256) NOT NULL COMMENT '网站关键字',
  `remark` text NOT NULL COMMENT '网站描述',
  `author` varchar(64) NOT NULL COMMENT '网站作者',
  `time` date NOT NULL COMMENT '建站时间',
  `icp` varchar(128) NOT NULL COMMENT '备案号',
  `copy` varchar(256) NOT NULL COMMENT '版权',
  `footer` text NOT NULL COMMENT '底部代码',
  `hit` int(11) NOT NULL COMMENT '总访问量',
  `url` varchar(128) NOT NULL DEFAULT 'www.loveteemo.com',
  `pay` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='系统基本设置';

-- 
-- 导出表中的数据 `web_system`
-- 

INSERT INTO `web_system` VALUES (1, 'LoveTeemo', '青春因为爱情而美丽', '个人博客，青春，爱情，IT，PHP，Thinkphp', '青春因为爱情而美丽', 'long', '2014-01-18', ' 鄂ICP备15000791号 ', '© 2014 - 2015 LoveTeemo博客 &amp; 版权所有 ', '<a href="./user" target="_blank" class="foot-my"> 博客管理 </a>', 15963, 'www.loveteemo.com', '0');

-- --------------------------------------------------------

-- 
-- 表的结构 `web_tag`
-- 

CREATE TABLE `web_tag` (
  `pid` int(11) NOT NULL AUTO_INCREMENT COMMENT '栏目逻辑id',
  `t_name` varchar(64) NOT NULL COMMENT '栏目显示名称',
  `t_open` int(11) NOT NULL DEFAULT '1' COMMENT '栏目打开方式',
  `t_sort` int(11) NOT NULL DEFAULT '100' COMMENT '栏目排序',
  `t_remark` text NOT NULL COMMENT '栏目描述',
  `t_view` int(11) NOT NULL DEFAULT '1' COMMENT '栏目视图',
  `t_time` int(10) NOT NULL COMMENT '栏目添加时间',
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='栏目表' AUTO_INCREMENT=5 ;

-- 
-- 导出表中的数据 `web_tag`
-- 

INSERT INTO `web_tag` VALUES (1, '学习笔记', 2, 100, '学习笔记', 1, 1436067161);
INSERT INTO `web_tag` VALUES (2, '生活随笔', 2, 100, '生活随笔', 1, 1436067169);
INSERT INTO `web_tag` VALUES (3, '热点分享', 2, 100, '热点分享', 1, 1436067179);
INSERT INTO `web_tag` VALUES (4, '程序相关', 2, 100, '程序相关', 1, 1436067188);

-- --------------------------------------------------------

-- 
-- 表的结构 `web_user`
-- 

CREATE TABLE `web_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户逻辑Id',
  `name` varchar(32) NOT NULL COMMENT '登陆用户名',
  `password` varchar(32) NOT NULL COMMENT '登陆密码',
  `user` varchar(32) NOT NULL COMMENT '用户名',
  `class` int(11) NOT NULL COMMENT '用户类别',
  `last_time` int(11) NOT NULL COMMENT '用户登陆时间',
  `ip` varchar(16) NOT NULL COMMENT '用户登陆ip',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='用户表' AUTO_INCREMENT=18 ;

-- 
-- 导出表中的数据 `web_user`
-- 

INSERT INTO `web_user` VALUES (17, 'test', 'test', 'test', 2, 1435650166, '218.22.37.73');

-- --------------------------------------------------------

-- 
-- 表的结构 `web_version`
-- 

CREATE TABLE `web_version` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '版本id',
  `title` varchar(256) NOT NULL COMMENT '标题',
  `content` text NOT NULL COMMENT '内容',
  `author` varchar(64) NOT NULL COMMENT '作者',
  `time` int(10) NOT NULL COMMENT '时间',
  `ip` varchar(16) NOT NULL COMMENT 'ip',
  `version` varchar(16) NOT NULL COMMENT '版本',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='程序版本表' AUTO_INCREMENT=16 ;

-- 
-- 导出表中的数据 `web_version`
-- 

INSERT INTO `web_version` VALUES (5, '更新版本删除和布局', '在后台模板中更新了版本删除功能和布局页面。', 'admin', 1430412590, '116.211.131.16', 'Beta v1.5.1a');
INSERT INTO `web_version` VALUES (11, '更新前台部分页面', '更新前台部分页面，首页，关于页纯静态。文章列表页，文章页。后续同步到服务器', 'admin', 1430467609, '116.211.131.16', 'Beta v1.5.1b');
INSERT INTO `web_version` VALUES (1, '测试版本1', '测试版本1', '隆航', 1430239169, '27.17.137.131', 'Beta v1.4.25b');
INSERT INTO `web_version` VALUES (2, '优化数据库文件', '把每一个文件的增删查改用一个模块写，方便后期修改', '隆航', 1430241314, '27.17.137.131', 'Beta v1.4.27a');
INSERT INTO `web_version` VALUES (4, '更新URL地址', '省略掉访问地址的Index.php，比如访问：www.loveteeemo.com/index.php/User/Login/index.html，则URL为www.loveteeemo.com/User/Login/index.html', 'admin', 1430410003, '116.211.131.16', 'Beta v1.4.30a');
INSERT INTO `web_version` VALUES (12, '完善sider的时光隧道部分', '完善sider的时光隧道部分，用户名，说说，文章统计，运行天数，随机文章，最新评论列表，修复一些BUG', 'admin', 1430591772, '116.211.131.16', 'Beta v1.5.3');
INSERT INTO `web_version` VALUES (13, '完成Listen说说列表模块和Said说说模块', '完成Listen说说列表模块和Said说说模块，其中Said的JS花的时候比较多，其他还待优化。\r\n大致程序写完了，会进行总体优化', 'admin', 1430784035, '116.211.131.16', 'Beta v1.5.5');
INSERT INTO `web_version` VALUES (14, '首页更新完成，数据完全通过', '首页完成，路由正则重写', '隆航', 1436143017, '106.39.189.187', 'Bate v1.7.5');
INSERT INTO `web_version` VALUES (15, '相册评论尚未完成。待开发。', '相册评论尚未完成。待开发。', '隆航', 1436574395, '114.111.167.14', 'Beta v1.7.11');
