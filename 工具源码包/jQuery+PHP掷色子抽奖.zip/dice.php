<?php
header("Content-type: text/html; charset=utf-8"); 

$prize_arr = array(
	'2' => array('id'=>2,'v'=>10),
	'3' => array('id'=>3,'v'=>20),
	'4' => array('id'=>4,'v'=>5),
	'5' => array('id'=>5,'v'=>5),
	'6' => array('id'=>6,'v'=>20),
	'7' => array('id'=>7,'v'=>2),
	'8' => array('id'=>8,'v'=>3),
	'9' => array('id'=>9,'v'=>20),
	'10' => array('id'=>10,'v'=>0),
	'11' => array('id'=>11,'v'=>10),
	'12' => array('id'=>12,'v'=>5),
);

foreach ($prize_arr as $key => $val) {
	$arr[$val['id']] = $val['v'];
}

$sum = getRand($arr); //根据概率获取奖项id


$arrs = array(
	'2' => array(array(1,1)),
	'3' => array(array(1,2)),
	'4' => array(array(1,3),array(2,2)),
	'5' => array(array(1,4),array(2,3)),
	'6' => array(array(1,5),array(2,4),array(3,3)),
	'7' => array(array(1,6),array(2,7),array(3,4)),
	'8' => array(array(2,6),array(3,5),array(4,4)),
	'9' => array(array(3,6),array(4,5)),
	'10' => array(array(4,6),array(5,5)),
	'11' => array(array(5,6)),
	'12' => array(array(6,6))
);

$arr_rs = $arrs[$sum];
$i = array_rand($arr_rs);//随机取数组
$arr_a = $arr_rs[$i];
shuffle($arr_a);//打乱顺序
//print_r($arr_a);
echo json_encode($arr_a);



//计算概率
function getRand($proArr) {
	$result = '';

	//概率数组的总概率精度
	$proSum = array_sum($proArr);

	//概率数组循环
	foreach ($proArr as $key => $proCur) {
		$randNum = mt_rand(1, $proSum);
		if ($randNum <= $proCur) {
			$result = $key;
			break;
		} else {
			$proSum -= $proCur;
		}
	}
	unset ($proArr);

	return $result;
}
?>