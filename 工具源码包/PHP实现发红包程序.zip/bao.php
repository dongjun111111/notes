<?php
header("Content-Type: text/html;charset=utf-8");


$total=20;//红包总额  
$num=10;// 分成10个红包，支持10人随机领取 
$min=0.01;//每个人最少能收到0.01元  


for ($i=1;$i<$num;$i++) {  
    $safe_total=($total-($num-$i)*$min)/($num-$i);//随机安全上限  
    $money=mt_rand($min*100,$safe_total*100)/100;  
    $total=$total-$money; 
	$arr['res'][$i] = array(
		'i' => $i,
		'money' => $money,
		'total' => $total
	);
} 
$arr['res'][$num] = array('i'=>$num,'money'=>$total,'total'=>0);
$arr['msg'] = 1;
echo json_encode($arr);
?>